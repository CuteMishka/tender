import{j as t,O as o}from"./index-EEkfLsR-.js";const n=()=>t.jsx(o,{});export{n as component};
