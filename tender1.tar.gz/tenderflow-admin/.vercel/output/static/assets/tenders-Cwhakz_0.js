import{j as t,O as o}from"./index-EEkfLsR-.js";function n(){return t.jsx(o,{})}export{n as component};
