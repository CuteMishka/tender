import { r as reactExports, j as jsxRuntimeExports } from "./_libs/react.mjs";
import { d as useNavigate, e as useLocation, O as Outlet, L as Link } from "./_libs/tanstack__react-router.mjs";
import { i as isAuthenticated, a as logout } from "./_ssr/auth-C1FwGTpK.mjs";
import { u as useNotifications } from "./_ssr/use-notifications-sQ8SQxfy.mjs";
import { C as Cloud, b as LayoutDashboard, G as Gavel, F as FileText, B as BookOpen, c as Bell, d as ChartNoAxesColumn, e as ChevronDown, f as ChevronRight, H as History, g as Building2, T as Trophy, h as TrendingDown, S as Settings, P as Palette, i as LogOut, j as CheckCheck, k as Trash2, X } from "./_libs/lucide-react.mjs";
import "./_libs/tanstack__router-core.mjs";
import "./_libs/tanstack__history.mjs";
import "./_libs/cookie-es.mjs";
import "./_libs/seroval.mjs";
import "./_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "./_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "./_libs/isbot.mjs";
const THEMES = [
  { key: "green", label: "Зелёная", color: "#11B273" },
  { key: "blue", label: "Синяя", color: "#3B82F6" },
  { key: "purple", label: "Фиолетовая", color: "#8B5CF6" },
  { key: "orange", label: "Оранжевая", color: "#F59E0B" },
  { key: "rose", label: "Розовая", color: "#F43F5E" }
];
const STORAGE_KEY = "tender_ui_theme";
function applyTheme(key) {
  document.documentElement.setAttribute("data-theme", key);
}
function useTheme() {
  const [theme, setThemeState] = reactExports.useState(() => {
    if (typeof window === "undefined") return "green";
    return localStorage.getItem(STORAGE_KEY) || "green";
  });
  reactExports.useEffect(() => {
    applyTheme(theme);
  }, [theme]);
  const setTheme = reactExports.useCallback((key) => {
    localStorage.setItem(STORAGE_KEY, key);
    setThemeState(key);
    applyTheme(key);
  }, []);
  return { theme, setTheme };
}
const mainNav = [
  { to: "/dashboard", label: "Дашборд", icon: LayoutDashboard },
  { to: "/tenders", label: "Тендеры", icon: Gavel, search: { page: 1 } },
  { to: "/bids", label: "Заявки", icon: FileText },
  { to: "/dictionaries", label: "Справочники", icon: BookOpen },
  { to: "/notifications", label: "Уведомления", icon: Bell }
];
const analyticsNav = [
  { to: "/analytics/historical", label: "История тендеров", icon: History },
  { to: "/analytics/customers", label: "Заказчики", icon: Building2 },
  { to: "/analytics/winners", label: "Победители", icon: Trophy },
  { to: "/analytics/prices", label: "Анализ цен", icon: TrendingDown }
];
const bottomNav = [
  { to: "/settings", label: "Настройки", icon: Settings }
];
function Sidebar() {
  const navigate = useNavigate();
  const location = useLocation();
  const isAnalytics = location.pathname.startsWith("/analytics");
  const [analyticsOpen, setAnalyticsOpen] = reactExports.useState(isAnalytics);
  const { unreadCount } = useNotifications();
  const { theme, setTheme } = useTheme();
  const [themeOpen, setThemeOpen] = reactExports.useState(false);
  const handleLogout = () => {
    logout();
    navigate({ to: "/login" });
  };
  const isActive = (path) => location.pathname === path || location.pathname.startsWith(path + "/");
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("aside", { className: "flex h-screen w-64 flex-col bg-sidebar text-sidebar-foreground", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 border-b border-sidebar-border px-6 py-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-10 w-10 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Cloud, { className: "h-5 w-5" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-base font-bold", children: "Freedom Cloud" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-sidebar-foreground/60", children: "Админ-панель" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("nav", { className: "flex-1 overflow-y-auto px-3 py-4 space-y-0.5", children: [
      mainNav.map((item) => {
        const Icon = item.icon;
        const active = isActive(item.to);
        const isNotifications = item.to === "/notifications";
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Link,
          {
            to: item.to,
            ..."search" in item ? { search: item.search } : {},
            className: `flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${active ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-md" : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-4 w-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex-1", children: item.label }),
              isNotifications && unreadCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex h-5 min-w-[20px] items-center justify-center rounded-full bg-red-500 px-1.5 text-[10px] font-bold text-white", children: unreadCount > 99 ? "99+" : unreadCount })
            ]
          },
          item.to
        );
      }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-3 pb-1", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          onClick: () => setAnalyticsOpen((v) => !v),
          className: "flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold uppercase tracking-wider text-sidebar-foreground/50 hover:text-sidebar-foreground/80 transition-colors",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ChartNoAxesColumn, { className: "h-3.5 w-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex-1 text-left", children: "Аналитика" }),
            analyticsOpen ? /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "h-3.5 w-3.5" })
          ]
        }
      ) }),
      analyticsOpen && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-0.5 pl-2", children: analyticsNav.map((item) => {
        const Icon = item.icon;
        const active = isActive(item.to);
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Link,
          {
            to: item.to,
            className: `flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${active ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-md" : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-4 w-4 shrink-0" }),
              item.label
            ]
          },
          item.to
        );
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-1", children: bottomNav.map((item) => {
        const Icon = item.icon;
        const active = isActive(item.to);
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Link,
          {
            to: item.to,
            className: `flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${active ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-md" : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-4 w-4" }),
              item.label
            ]
          },
          item.to
        );
      }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border-t border-sidebar-border px-3 pt-3 pb-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          onClick: () => setThemeOpen((v) => !v),
          className: "flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold uppercase tracking-wider text-sidebar-foreground/50 hover:text-sidebar-foreground/80 transition-colors",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Palette, { className: "h-3.5 w-3.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex-1 text-left", children: "Тема" })
          ]
        }
      ),
      themeOpen && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-1 flex flex-wrap gap-2 px-3 pb-2", children: THEMES.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => setTheme(t.key),
          title: t.label,
          className: `h-6 w-6 rounded-full border-2 transition-transform hover:scale-110 ${theme === t.key ? "border-white scale-110 shadow-lg" : "border-transparent opacity-70"}`,
          style: { backgroundColor: t.color }
        },
        t.key
      )) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border-t border-sidebar-border p-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-3 flex items-center gap-3 rounded-lg px-3 py-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-9 w-9 items-center justify-center rounded-full bg-sidebar-primary font-semibold text-sidebar-primary-foreground", children: "A" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "truncate text-sm font-medium", children: "Администратор" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "truncate text-xs text-sidebar-foreground/60", children: "admin@tender.ru" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          onClick: handleLogout,
          className: "flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-sidebar-foreground/80 transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "h-4 w-4" }),
            "Выйти"
          ]
        }
      )
    ] })
  ] });
}
const typeStyles = {
  success: {
    dot: "bg-green-500",
    bg: "border-l-green-500"
  },
  warning: {
    dot: "bg-yellow-500",
    bg: "border-l-yellow-500"
  },
  error: {
    dot: "bg-red-500",
    bg: "border-l-red-500"
  },
  info: {
    dot: "bg-blue-500",
    bg: "border-l-blue-500"
  }
};
function timeAgo(ts) {
  const diff = Date.now() - ts;
  const min = Math.floor(diff / 6e4);
  if (min < 1) return "только что";
  if (min < 60) return `${min} мин. назад`;
  const h = Math.floor(min / 60);
  if (h < 24) return `${h} ч. назад`;
  return `${Math.floor(h / 24)} дн. назад`;
}
function NotificationBell() {
  const {
    notifications,
    unreadCount,
    markAllRead,
    markRead,
    clearAll,
    remove
  } = useNotifications();
  const [open, setOpen] = reactExports.useState(false);
  const ref = reactExports.useRef(null);
  const navigate = useNavigate();
  reactExports.useEffect(() => {
    function handleClick(e) {
      if (ref.current && !ref.current.contains(e.target)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { ref, className: "relative", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => {
      setOpen((o) => !o);
    }, className: "relative flex h-9 w-9 items-center justify-center rounded-full border border-border bg-background text-muted-foreground transition-colors hover:bg-accent hover:text-foreground", "aria-label": "Уведомления", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Bell, { className: "h-4 w-4" }),
      unreadCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white", children: unreadCount > 9 ? "9+" : unreadCount })
    ] }),
    open && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute right-0 top-11 z-50 w-80 overflow-hidden rounded-xl border border-border bg-card shadow-xl animate-in fade-in-0 slide-in-from-top-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between border-b border-border px-4 py-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-semibold", children: "Уведомления" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1", children: notifications.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: markAllRead, title: "Отметить все как прочитанные", className: "rounded p-1.5 text-muted-foreground hover:bg-accent hover:text-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CheckCheck, { className: "h-3.5 w-3.5" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: clearAll, title: "Очистить все", className: "rounded p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-3.5 w-3.5" }) })
        ] }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-h-96 overflow-y-auto", children: notifications.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center justify-center py-10 text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Bell, { className: "mb-2 h-8 w-8 opacity-30" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm", children: "Нет уведомлений" })
      ] }) : notifications.map((n) => {
        const s = typeStyles[n.type];
        return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `group relative border-l-2 px-4 py-3 transition hover:bg-muted/40 ${s.bg} ${!n.read ? "bg-muted/20" : ""}`, onClick: () => {
          markRead(n.id);
          if (n.link) {
            setOpen(false);
            navigate({
              to: n.link
            });
          }
        }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `mt-1.5 h-2 w-2 shrink-0 rounded-full ${s.dot}` }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-semibold text-foreground", children: n.title }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-0.5 line-clamp-2 text-xs text-muted-foreground", children: n.message }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-[10px] text-muted-foreground/60", children: timeAgo(n.timestamp) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: (e) => {
            e.stopPropagation();
            remove(n.id);
          }, className: "invisible shrink-0 rounded p-0.5 text-muted-foreground hover:text-foreground group-hover:visible", children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-3 w-3" }) })
        ] }) }, n.id);
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "border-t border-border px-4 py-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => {
        setOpen(false);
        navigate({
          to: "/notifications"
        });
      }, className: "w-full rounded-lg px-3 py-2 text-center text-xs font-medium text-primary hover:bg-accent", children: "Открыть центр уведомлений" }) })
    ] })
  ] });
}
function AdminLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const [ready, setReady] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (!isAuthenticated()) {
      navigate({
        to: "/login",
        replace: true
      });
    } else {
      setReady(true);
    }
  }, [navigate]);
  if (!ready) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-10 w-10 animate-spin rounded-full border-2 border-muted border-t-primary" }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex h-screen overflow-hidden bg-background", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Sidebar, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-1 flex-col overflow-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed right-6 top-4 z-40", children: /* @__PURE__ */ jsxRuntimeExports.jsx(NotificationBell, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("main", { className: "flex-1 overflow-y-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "animate-in fade-in-0 slide-in-from-bottom-3 duration-200 min-h-full", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Outlet, {}) }, location.pathname) })
    ] })
  ] });
}
export {
  AdminLayout as component
};
