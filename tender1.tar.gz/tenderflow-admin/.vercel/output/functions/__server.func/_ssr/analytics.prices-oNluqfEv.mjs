import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { P as PageHeader } from "./PageHeader-BgLmG3Y0.mjs";
import { a as analyticsApi, d as fmtPct, f as fmtM, c as fmtN } from "./analytics-api-B0h335SN.mjs";
import { a as CircleAlert, l as Search, h as TrendingDown, V as TriangleAlert } from "../_libs/lucide-react.mjs";
import { R as ResponsiveContainer, B as BarChart, b as CartesianGrid, X as XAxis, Y as YAxis, T as Tooltip, c as Bar, S as ScatterChart, Z as ZAxis, d as Scatter } from "../_libs/recharts.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "./tenders-api-s2Iw9WUl.mjs";
import "../_libs/clsx.mjs";
import "../_libs/lodash.mjs";
import "../_libs/react-smooth.mjs";
import "../_libs/prop-types.mjs";
import "../_libs/fast-equals.mjs";
import "../_libs/tiny-invariant.mjs";
import "../_libs/react-is.mjs";
import "../_libs/d3-shape.mjs";
import "../_libs/d3-path.mjs";
import "../_libs/victory-vendor.mjs";
import "../_libs/d3-scale.mjs";
import "../_libs/internmap.mjs";
import "../_libs/d3-array.mjs";
import "../_libs/d3-time-format.mjs";
import "../_libs/d3-time.mjs";
import "../_libs/d3-interpolate.mjs";
import "../_libs/d3-color.mjs";
import "../_libs/d3-format.mjs";
import "../_libs/recharts-scale.mjs";
import "../_libs/decimal.js-light.mjs";
import "../_libs/eventemitter3.mjs";
function PriceAnalytics() {
  const [priceStats, setPriceStats] = reactExports.useState(null);
  const [rows, setRows] = reactExports.useState([]);
  const [loading, setLoading] = reactExports.useState(true);
  const [tab, setTab] = reactExports.useState("all");
  const [searchText, setSearchText] = reactExports.useState("");
  reactExports.useEffect(() => {
    analyticsApi.getPrices().then((d) => {
      setPriceStats(d.stats);
      setRows(d.rows ?? []);
    }).catch(console.error).finally(() => setLoading(false));
  }, []);
  const searchedRows = rows.filter((r) => {
    const q = searchText.trim().toLowerCase();
    if (!q) return true;
    return `${r.lot_id} ${r.title} ${r.customer_name} ${r.purchase_type} ${r.winner_name} ${r.initial_amount} ${r.contract_amount} ${r.discount_pct}`.toLowerCase().includes(q);
  });
  const anomalies = searchedRows.filter((r) => r.discount_pct >= 40);
  const displayRows = tab === "anomalies" ? anomalies : searchedRows;
  const discountBuckets = {
    "0–5%": 0,
    "5–10%": 0,
    "10–20%": 0,
    "20–30%": 0,
    "30–40%": 0,
    ">40%": 0
  };
  for (const r of rows) {
    const d = r.discount_pct;
    if (d < 5) discountBuckets["0–5%"]++;
    else if (d < 10) discountBuckets["5–10%"]++;
    else if (d < 20) discountBuckets["10–20%"]++;
    else if (d < 30) discountBuckets["20–30%"]++;
    else if (d < 40) discountBuckets["30–40%"]++;
    else discountBuckets[">40%"]++;
  }
  const histData = Object.entries(discountBuckets).map(([name, count]) => ({
    name,
    count
  }));
  const scatterData = rows.slice(0, 200).map((r) => ({
    x: +(r.initial_amount / 1e6).toFixed(2),
    y: +(r.contract_amount / 1e6).toFixed(2),
    z: r.discount_pct
  }));
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { title: "Анализ цен", description: "Сравнение начальных и итоговых цен контрактов, выявление демпинга" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6 p-8", children: loading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-center py-24 text-sm text-muted-foreground", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mr-2 h-5 w-5 animate-spin rounded-full border-2 border-muted border-t-primary" }),
      " Загрузка…"
    ] }) : rows.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center justify-center rounded-xl border border-border bg-card py-24 text-muted-foreground", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "mb-3 h-10 w-10 opacity-20" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium", children: "Нет данных о ценах контрактов" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs", children: "Данные появятся после того как будут внесены суммы контрактов в историю тендеров" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/analytics/historical", className: "mt-4 inline-flex items-center gap-1.5 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90", children: "Перейти в историю тендеров" })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative max-w-xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: searchText, onChange: (e) => setSearchText(e.target.value), placeholder: "Поиск по названию, заказчику, виду закупки, победителю...", className: "w-full rounded-lg border border-input bg-background py-2 pl-9 pr-3 text-sm" })
      ] }),
      priceStats && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card p-5", style: {
          boxShadow: "var(--shadow-sm)"
        }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-2 flex items-center gap-2 text-xs text-muted-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TrendingDown, { className: "h-4 w-4 text-green-600" }),
            " Средняя скидка"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-2xl font-bold text-green-600", children: fmtPct(priceStats.avg_discount_pct) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-0.5 text-xs text-muted-foreground", children: "от начальной цены" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card p-5", style: {
          boxShadow: "var(--shadow-sm)"
        }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-2 text-xs text-muted-foreground", children: "Макс. скидка" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-2xl font-bold", children: fmtPct(priceStats.max_discount_pct) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-0.5 text-xs text-muted-foreground", children: [
            "мин: ",
            fmtPct(priceStats.min_discount_pct)
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card p-5", style: {
          boxShadow: "var(--shadow-sm)"
        }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-2 flex items-center gap-2 text-xs text-muted-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "h-4 w-4 text-red-500" }),
            " Аномалии (>40%)"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-2xl font-bold text-red-600", children: priceStats.anomaly_count }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-0.5 text-xs text-muted-foreground", children: [
            "из ",
            searchedRows.length,
            " контрактов"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card p-5", style: {
          boxShadow: "var(--shadow-sm)"
        }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-2 text-xs text-muted-foreground", children: "Суммарная экономия" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-2xl font-bold text-primary", children: [
            "₸ ",
            fmtM(priceStats.total_savings)
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-0.5 text-xs text-muted-foreground", children: [
            "Ср. нач.: ",
            fmtM(priceStats.avg_initial),
            " → Ср. контракт: ",
            fmtM(priceStats.avg_contract)
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 lg:grid-cols-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card p-6", style: {
          boxShadow: "var(--shadow-sm)"
        }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mb-1 text-sm font-semibold", children: "Распределение скидок" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-4 text-xs text-muted-foreground", children: "Количество контрактов по диапазонам снижения цены" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ResponsiveContainer, { width: "100%", height: 200, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(BarChart, { data: histData, margin: {
            top: 0,
            right: 0,
            left: -20,
            bottom: 0
          }, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CartesianGrid, { strokeDasharray: "3 3", stroke: "var(--border)" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(XAxis, { dataKey: "name", tick: {
              fontSize: 11
            } }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(YAxis, { tick: {
              fontSize: 11
            } }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Tooltip, { formatter: (v) => [v, "Контрактов"] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Bar, { dataKey: "count", radius: [4, 4, 0, 0], fill: "var(--primary)" })
          ] }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card p-6", style: {
          boxShadow: "var(--shadow-sm)"
        }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mb-1 text-sm font-semibold", children: "Нач. цена vs Контракт (млн ₸)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-4 text-xs text-muted-foreground", children: "Каждая точка — один контракт; цвет — величина скидки" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ResponsiveContainer, { width: "100%", height: 200, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(ScatterChart, { margin: {
            top: 0,
            right: 0,
            left: -20,
            bottom: 0
          }, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CartesianGrid, { strokeDasharray: "3 3", stroke: "var(--border)" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(XAxis, { dataKey: "x", name: "Нач. цена", tick: {
              fontSize: 11
            }, unit: " млн" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(YAxis, { dataKey: "y", name: "Контракт", tick: {
              fontSize: 11
            }, unit: " млн" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ZAxis, { dataKey: "z", range: [40, 200], name: "Скидка %" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Tooltip, { cursor: {
              strokeDasharray: "3 3"
            }, formatter: (v, name) => name === "Нач. цена" || name === "Контракт" ? [`${v} млн ₸`, name] : [`${v}%`, "Скидка"] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Scatter, { data: scatterData, fill: "var(--primary)", opacity: 0.6 })
          ] }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "overflow-hidden rounded-xl border border-border bg-card", style: {
        boxShadow: "var(--shadow-sm)"
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between border-b border-border px-6 py-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold", children: "Детализация по контрактам" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "Отсортировано по убыванию скидки" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => setTab("all"), className: `rounded-lg px-3 py-1.5 text-xs font-medium transition ${tab === "all" ? "bg-primary text-primary-foreground" : "border border-border bg-background hover:bg-accent"}`, children: [
              "Все (",
              searchedRows.length,
              ")"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => setTab("anomalies"), className: `inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition ${tab === "anomalies" ? "bg-red-600 text-white" : "border border-border bg-background hover:bg-accent"}`, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "h-3 w-3" }),
              " Аномалии (",
              anomalies.length,
              ")"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full min-w-[900px] text-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-left font-medium", children: "ID" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-left font-medium", children: "Наименование" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-left font-medium", children: "Заказчик" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-left font-medium", children: "Вид закупки" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-right font-medium", children: "Нач. цена ₸" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-right font-medium", children: "Контракт ₸" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-right font-medium", children: "Скидка ₸" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-right font-medium", children: "Скидка %" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-left font-medium", children: "Победитель" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("tbody", { children: [
            displayRows.map((row) => {
              const isAnomaly = row.discount_pct >= 40;
              return /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: `border-t border-border hover:bg-muted/30 ${isAnomaly ? "bg-red-50/50" : ""}`, children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 font-mono text-xs text-muted-foreground", children: row.lot_id }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 max-w-[220px] truncate font-medium text-foreground", children: row.title }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 max-w-[150px] truncate text-xs text-muted-foreground", children: row.customer_name || "—" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 text-xs text-muted-foreground", children: row.purchase_type || "—" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 text-right tabular-nums", children: fmtN(row.initial_amount) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 text-right tabular-nums", children: fmtN(row.contract_amount) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 text-right tabular-nums text-green-700", children: fmtM(row.discount_abs) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 text-right", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `inline-flex rounded-full px-2 py-0.5 text-xs font-semibold ${isAnomaly ? "bg-red-100 text-red-700" : row.discount_pct >= 20 ? "bg-orange-100 text-orange-700" : "bg-green-100 text-green-700"}`, children: [
                  isAnomaly && "⚠ ",
                  fmtPct(row.discount_pct)
                ] }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 max-w-[140px] truncate text-xs text-muted-foreground", children: row.winner_name || "—" })
              ] }, row.lot_id);
            }),
            displayRows.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("td", { colSpan: 9, className: "px-6 py-12 text-center text-sm text-muted-foreground", children: searchText.trim() ? "По заданному поиску контракты не найдены" : tab === "anomalies" ? "Аномалии не обнаружены" : "Нет данных" }) })
          ] })
        ] }) })
      ] })
    ] }) })
  ] });
}
export {
  PriceAnalytics as component
};
