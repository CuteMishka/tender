import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { P as PageHeader } from "./PageHeader-BgLmG3Y0.mjs";
import { l as Search, g as Building2, u as BadgeCheck, v as MapPin } from "../_libs/lucide-react.mjs";
const companies = [{
  name: "ООО «Рассвет»",
  inn: "7701234567",
  city: "Москва",
  tenders: 24,
  verified: true
}, {
  name: "СК «СтройМаш»",
  inn: "7812345678",
  city: "Санкт-Петербург",
  tenders: 18,
  verified: true
}, {
  name: "TechFlow Ltd.",
  inn: "7723456789",
  city: "Москва",
  tenders: 32,
  verified: true
}, {
  name: "МедПром",
  inn: "5034567890",
  city: "Подольск",
  tenders: 9,
  verified: false
}, {
  name: "ЧистоПлюс",
  inn: "7745678901",
  city: "Москва",
  tenders: 12,
  verified: true
}, {
  name: "АльфаКонсалт",
  inn: "7856789012",
  city: "Казань",
  tenders: 7,
  verified: false
}];
function Companies() {
  const [searchText, setSearchText] = reactExports.useState("");
  const visibleCompanies = companies.filter((c) => {
    const q = searchText.trim().toLowerCase();
    if (!q) return true;
    return `${c.name} ${c.inn} ${c.city} ${c.verified ? "проверен verified" : "не проверен"}`.toLowerCase().includes(q);
  });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { title: "Компании", description: "Реестр зарегистрированных организаций" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 p-8", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative max-w-xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: searchText, onChange: (e) => setSearchText(e.target.value), placeholder: "Поиск по компании, ИНН, городу...", className: "w-full rounded-lg border border-input bg-background py-2 pl-9 pr-3 text-sm" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-4 md:grid-cols-2 xl:grid-cols-3", children: visibleCompanies.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card p-5 transition hover:border-primary/40", style: {
        boxShadow: "var(--shadow-sm)"
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className: "h-6 w-6" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "truncate font-semibold text-foreground", children: c.name }),
              c.verified && /* @__PURE__ */ jsxRuntimeExports.jsx(BadgeCheck, { className: "h-4 w-4 shrink-0 text-primary" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-0.5 font-mono text-xs text-muted-foreground", children: [
              "ИНН ",
              c.inn
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-1 flex items-center gap-1 text-xs text-muted-foreground", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "h-3 w-3" }),
              " ",
              c.city
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex items-center justify-between border-t border-border pt-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "Участие в тендерах" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg font-bold text-foreground", children: c.tenders })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "rounded-lg border border-border bg-background px-3 py-1.5 text-xs font-medium hover:bg-accent", children: "Подробнее" })
        ] })
      ] }, c.inn)) }),
      visibleCompanies.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-xl border border-border bg-card py-16 text-center text-sm text-muted-foreground", children: "По компаниям ничего не найдено" })
    ] })
  ] });
}
export {
  Companies as component
};
