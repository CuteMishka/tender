import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { d as useNavigate } from "../_libs/tanstack__react-router.mjs";
import { P as PageHeader } from "./PageHeader-BgLmG3Y0.mjs";
import { u as useNotifications, p as pushNotification } from "./use-notifications-sQ8SQxfy.mjs";
import { m as Users, M as MessageSquare, R as RefreshCw, G as Gavel, n as Clock, c as Bell, o as Megaphone, j as CheckCheck, k as Trash2, l as Search, X } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
const categoryMeta = {
  all: {
    label: "Все",
    icon: Bell
  },
  deadline: {
    label: "Дедлайны",
    icon: Clock
  },
  appeal: {
    label: "Обжалования",
    icon: Gavel
  },
  updates: {
    label: "Обновления",
    icon: RefreshCw
  },
  mentions: {
    label: "Упоминания",
    icon: MessageSquare
  },
  review: {
    label: "Ревью и решения",
    icon: Users
  }
};
const typeTone = {
  success: "bg-green-100 text-green-700",
  warning: "bg-orange-100 text-orange-700",
  error: "bg-red-100 text-red-700",
  info: "bg-blue-100 text-blue-700"
};
function formatTime(ts) {
  return new Date(ts).toLocaleString("ru-KZ", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
}
function getDateGroup(ts) {
  const d = new Date(ts);
  const today = /* @__PURE__ */ new Date();
  const yesterday = /* @__PURE__ */ new Date();
  yesterday.setDate(today.getDate() - 1);
  if (d.toDateString() === today.toDateString()) return "Сегодня";
  if (d.toDateString() === yesterday.toDateString()) return "Вчера";
  const diffDays = Math.floor((today.getTime() - d.getTime()) / 864e5);
  if (diffDays < 7) return "На этой неделе";
  return "Ранее";
}
const DATE_GROUP_ORDER = ["Сегодня", "Вчера", "На этой неделе", "Ранее"];
function seedNotifications() {
  pushNotification("warning", "Дедлайн через 2 дня", "Лот требует первичной фильтрации и решения по участию.", "/tenders", "deadline");
  pushNotification("info", "Новый лот по ключевым словам", "Парсер нашёл закупку по справочнику ключевых слов.", "/tenders", "updates");
  pushNotification("success", "Заказчик добавлен в избранное", "Отслеживание заказчика активно для новых закупок.", "/analytics/customers", "mentions");
}
function NotificationsPage() {
  const navigate = useNavigate();
  const {
    notifications,
    unreadCount,
    markAllRead,
    markCategoryRead,
    markRead,
    clearAll,
    remove
  } = useNotifications();
  const [active, setActive] = reactExports.useState("all");
  const [searchText, setSearchText] = reactExports.useState("");
  const tabs = reactExports.useMemo(() => ["all", "deadline", "appeal", "updates", "mentions", "review"].map((key) => {
    const count = key === "all" ? notifications.length : notifications.filter((n) => n.category === key).length;
    const unread = key === "all" ? unreadCount : notifications.filter((n) => n.category === key && !n.read).length;
    return {
      key,
      count,
      unread,
      ...categoryMeta[key]
    };
  }), [notifications, unreadCount]);
  const visible = (active === "all" ? notifications : notifications.filter((n) => n.category === active)).filter((n) => {
    const q = searchText.trim().toLowerCase();
    if (!q) return true;
    return `${n.title} ${n.message} ${n.type} ${categoryMeta[n.category].label}`.toLowerCase().includes(q);
  });
  const grouped = reactExports.useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    for (const n of visible) {
      const g = getDateGroup(n.timestamp);
      if (!map.has(g)) map.set(g, []);
      map.get(g).push(n);
    }
    const result = [];
    for (const g of DATE_GROUP_ORDER) {
      if (map.has(g)) result.push({
        group: g,
        items: map.get(g)
      });
    }
    return result;
  }, [visible]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { title: "Уведомления", description: `${unreadCount} непрочитанных · дедлайны, обновления, упоминания и ревью`, actions: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: seedNotifications, className: "inline-flex items-center gap-2 rounded-lg border border-border bg-background px-4 py-2 text-sm font-medium hover:bg-accent", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Megaphone, { className: "h-4 w-4" }),
        " Тестовые"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => active === "all" ? markAllRead() : markCategoryRead(active), className: "inline-flex items-center gap-2 rounded-lg border border-border bg-background px-4 py-2 text-sm font-medium hover:bg-accent", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CheckCheck, { className: "h-4 w-4" }),
        " Отметить прочитанными"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: clearAll, className: "inline-flex items-center gap-2 rounded-lg border border-border bg-background px-4 py-2 text-sm font-medium text-destructive hover:bg-destructive/10", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }),
        " Очистить"
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5 p-8", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: tabs.map((tab) => {
        const Icon = tab.icon;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => setActive(tab.key), className: `inline-flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition ${active === tab.key ? "bg-primary text-primary-foreground" : "border border-border bg-card hover:bg-accent"}`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-4 w-4" }),
          tab.label,
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `rounded-full px-1.5 py-0.5 text-[10px] ${active === tab.key ? "bg-primary-foreground/20" : "bg-muted text-muted-foreground"}`, children: tab.count }),
          tab.unread > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rounded-full bg-red-500 px-1.5 py-0.5 text-[10px] text-white", children: tab.unread })
        ] }, tab.key);
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative max-w-xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: searchText, onChange: (e) => setSearchText(e.target.value), placeholder: "Поиск по уведомлениям, типу, категории...", className: "w-full rounded-lg border border-input bg-background py-2 pl-9 pr-3 text-sm" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-hidden rounded-xl border border-border bg-card", style: {
        boxShadow: "var(--shadow-sm)"
      }, children: visible.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center justify-center py-20 text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Bell, { className: "mb-3 h-10 w-10 opacity-20" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium", children: searchText.trim() ? "Уведомления не найдены" : "Уведомлений пока нет" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs", children: searchText.trim() ? "Попробуйте другой поисковый запрос." : "Они появятся при действиях с тендерами, заказчиками и дедлайнами." })
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: grouped.map(({
        group,
        items
      }) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "sticky top-0 z-10 border-b border-border bg-muted/60 px-6 py-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground backdrop-blur", children: [
          group,
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "ml-1 font-normal normal-case", children: [
            "· ",
            items.length
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "divide-y divide-border", children: items.map((n) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `group flex gap-4 px-6 py-4 transition hover:bg-muted/30 ${!n.read ? "bg-primary/5" : ""}`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `mt-1 h-2.5 w-2.5 shrink-0 rounded-full ${n.read ? "bg-muted-foreground/30" : "bg-primary"}` }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => {
            markRead(n.id);
            if (n.link) navigate({
              to: n.link
            });
          }, className: "min-w-0 flex-1 text-left", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase ${typeTone[n.type]}`, children: n.type }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rounded-full bg-muted px-2 py-0.5 text-[10px] text-muted-foreground", children: categoryMeta[n.category].label }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-muted-foreground", children: formatTime(n.timestamp) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 font-semibold text-foreground", children: n.title }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-0.5 text-sm text-muted-foreground", children: n.message })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => remove(n.id), className: "h-8 w-8 shrink-0 rounded-lg text-muted-foreground hover:bg-accent hover:text-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "mx-auto h-4 w-4" }) })
        ] }, n.id)) })
      ] }, group)) }) })
    ] })
  ] });
}
export {
  NotificationsPage as component
};
