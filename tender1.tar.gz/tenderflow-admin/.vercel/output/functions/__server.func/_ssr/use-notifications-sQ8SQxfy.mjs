import { r as reactExports } from "../_libs/react.mjs";
const STORAGE_KEY = "tender_notifications";
const MAX_NOTIFICATIONS = 200;
function loadFromStorage() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.map((n) => ({ category: "updates", ...n })) : [];
  } catch {
    return [];
  }
}
function saveToStorage(items) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items.slice(0, MAX_NOTIFICATIONS)));
  } catch {
  }
}
const NOTIFY_EVENT = "tender_notify_update";
function pushNotification(type, title, message, link, category = "updates") {
  const current = loadFromStorage();
  const item = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    type,
    category,
    title,
    message,
    timestamp: Date.now(),
    read: false,
    link
  };
  const updated = [item, ...current].slice(0, MAX_NOTIFICATIONS);
  saveToStorage(updated);
  window.dispatchEvent(new CustomEvent(NOTIFY_EVENT));
}
function useNotifications() {
  const [notifications, setNotifications] = reactExports.useState(loadFromStorage);
  const refresh = reactExports.useCallback(() => {
    setNotifications(loadFromStorage());
  }, []);
  reactExports.useEffect(() => {
    window.addEventListener(NOTIFY_EVENT, refresh);
    return () => window.removeEventListener(NOTIFY_EVENT, refresh);
  }, [refresh]);
  const unreadCount = notifications.filter((n) => !n.read).length;
  const markAllRead = reactExports.useCallback(() => {
    const updated = loadFromStorage().map((n) => ({ ...n, read: true }));
    saveToStorage(updated);
    setNotifications(updated);
  }, []);
  const markCategoryRead = reactExports.useCallback((category) => {
    const updated = loadFromStorage().map((n) => n.category === category ? { ...n, read: true } : n);
    saveToStorage(updated);
    setNotifications(updated);
  }, []);
  const markRead = reactExports.useCallback((id) => {
    const updated = loadFromStorage().map((n) => n.id === id ? { ...n, read: true } : n);
    saveToStorage(updated);
    setNotifications(updated);
  }, []);
  const clearAll = reactExports.useCallback(() => {
    saveToStorage([]);
    setNotifications([]);
  }, []);
  const remove = reactExports.useCallback((id) => {
    const updated = loadFromStorage().filter((n) => n.id !== id);
    saveToStorage(updated);
    setNotifications(updated);
  }, []);
  return { notifications, unreadCount, markAllRead, markCategoryRead, markRead, clearAll, remove };
}
export {
  pushNotification as p,
  useNotifications as u
};
