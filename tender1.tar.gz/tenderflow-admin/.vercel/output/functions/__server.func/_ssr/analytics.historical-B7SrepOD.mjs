import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { P as PageHeader } from "./PageHeader-BgLmG3Y0.mjs";
import { u as useToast, T as ToastContainer } from "./PageToast-BnKBPqEf.mjs";
import { a as analyticsApi, f as fmtM, c as fmtN, b as fmtDate } from "./analytics-api-B0h335SN.mjs";
import { y as Funnel, W as FileSpreadsheet, R as RefreshCw, K as Hash, t as DollarSign, Y as Percent, Z as TrendingUp, _ as Pencil, d as ChartNoAxesColumn, $ as EyeOff, g as Building2, a0 as Star, a1 as RotateCcw, k as Trash2, a2 as ChevronLeft, f as ChevronRight, X, q as Check } from "../_libs/lucide-react.mjs";
import { R as ResponsiveContainer, B as BarChart, b as CartesianGrid, X as XAxis, Y as YAxis, T as Tooltip, c as Bar, L as LineChart, e as Line } from "../_libs/recharts.mjs";
import "./tenders-api-s2Iw9WUl.mjs";
import "../_libs/clsx.mjs";
import "../_libs/lodash.mjs";
import "../_libs/react-smooth.mjs";
import "../_libs/prop-types.mjs";
import "../_libs/fast-equals.mjs";
import "../_libs/tiny-invariant.mjs";
import "../_libs/react-is.mjs";
import "../_libs/d3-shape.mjs";
import "../_libs/d3-path.mjs";
import "../_libs/victory-vendor.mjs";
import "../_libs/d3-scale.mjs";
import "../_libs/internmap.mjs";
import "../_libs/d3-array.mjs";
import "../_libs/d3-time-format.mjs";
import "../_libs/d3-time.mjs";
import "../_libs/d3-interpolate.mjs";
import "../_libs/d3-color.mjs";
import "../_libs/d3-format.mjs";
import "../_libs/recharts-scale.mjs";
import "../_libs/decimal.js-light.mjs";
import "../_libs/eventemitter3.mjs";
function StatCard({
  label,
  value,
  sub,
  icon: Icon,
  accent
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card p-5", style: {
    boxShadow: "var(--shadow-sm)"
  }, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `mb-3 flex h-10 w-10 items-center justify-center rounded-lg ${accent}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-5 w-5" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: label }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-2xl font-bold", children: value }),
    sub && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-0.5 text-xs text-muted-foreground", children: sub })
  ] });
}
function EditModal({
  state,
  onSave,
  onClose,
  saving
}) {
  const [winnerName, setWinnerName] = reactExports.useState(state.winner_name);
  const [contractAmount, setContractAmount] = reactExports.useState(state.contract_amount);
  const [status, setStatus] = reactExports.useState(state.status);
  reactExports.useEffect(() => {
    const handler = (e) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [onClose]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-in fade-in-0 duration-150", onClick: onClose, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full max-w-md rounded-xl border border-border bg-card p-6 shadow-2xl animate-in zoom-in-95 duration-150", onClick: (e) => e.stopPropagation(), children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-start justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-semibold", children: "Внесение результатов" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-0.5 text-xs text-muted-foreground line-clamp-2", children: state.lot.title })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: onClose, className: "shrink-0 rounded-lg p-1.5 hover:bg-accent", children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4" }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "mb-1 block text-xs font-medium text-muted-foreground", children: "Победитель" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: winnerName, onChange: (e) => setWinnerName(e.target.value), placeholder: "Название компании-победителя", className: "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "mb-1 block text-xs font-medium text-muted-foreground", children: "Сумма контракта ₸" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "number", value: contractAmount, onChange: (e) => setContractAmount(e.target.value), placeholder: "0", min: "0", className: "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "mb-1 block text-xs font-medium text-muted-foreground", children: "Статус" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("select", { value: status, onChange: (e) => setStatus(e.target.value), className: "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "", children: "— выбрать —" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "active", children: "Активный" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "completed", children: "Завершён" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "cancelled", children: "Отменён" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 flex justify-end gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: onClose, className: "rounded-lg border border-border px-4 py-2 text-sm font-medium hover:bg-accent transition-colors", children: "Отмена" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => onSave({
        winner_name: winnerName,
        contract_amount: parseFloat(contractAmount) || 0,
        status
      }), disabled: saving, className: "inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-50", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "h-4 w-4" }),
        saving ? "Сохранение…" : "Сохранить"
      ] })
    ] })
  ] }) });
}
function HistoricalAnalytics() {
  const toast = useToast();
  const [stats, setStats] = reactExports.useState(null);
  const [dynamics, setDynamics] = reactExports.useState([]);
  const [lots, setLots] = reactExports.useState([]);
  const [total, setTotal] = reactExports.useState(0);
  const [pageCount, setPageCount] = reactExports.useState(1);
  const [filterOptions, setFilterOptions] = reactExports.useState({
    purchase_types: [],
    regions: []
  });
  const [loading, setLoading] = reactExports.useState(true);
  const [syncing, setSyncing] = reactExports.useState(false);
  const [showFilters, setShowFilters] = reactExports.useState(false);
  const [editState, setEditState] = reactExports.useState(null);
  const [saving, setSaving] = reactExports.useState(false);
  const [trackedCustomerNames, setTrackedCustomerNames] = reactExports.useState(/* @__PURE__ */ new Set());
  const [page, setPage] = reactExports.useState(1);
  const [filterCustomer, setFilterCustomer] = reactExports.useState("");
  const [filterType, setFilterType] = reactExports.useState("");
  const [filterRegion, setFilterRegion] = reactExports.useState("");
  const [filterDateFrom, setFilterDateFrom] = reactExports.useState("");
  const [filterDateTo, setFilterDateTo] = reactExports.useState("");
  const [filterAmountMin, setFilterAmountMin] = reactExports.useState("");
  const [filterAmountMax, setFilterAmountMax] = reactExports.useState("");
  const [onlyOurParticipation, setOnlyOurParticipation] = reactExports.useState(false);
  const [excludedMode, setExcludedMode] = reactExports.useState("active");
  const loadAll = reactExports.useCallback(async () => {
    setLoading(true);
    try {
      const [s, d, l, fo, customers] = await Promise.all([analyticsApi.getStats(), analyticsApi.getDynamics(), analyticsApi.getLots({
        customer: filterCustomer || void 0,
        purchase_type: filterType || void 0,
        region: filterRegion || void 0,
        date_from: filterDateFrom || void 0,
        date_to: filterDateTo || void 0,
        amount_min: filterAmountMin || void 0,
        amount_max: filterAmountMax || void 0,
        participation: onlyOurParticipation ? "our" : void 0,
        excluded: excludedMode === "only" ? "only" : void 0,
        page,
        limit: 20
      }), analyticsApi.getFilters(), analyticsApi.getCustomers()]);
      setStats(s);
      setDynamics(d ?? []);
      setLots(l.items ?? []);
      setTotal(l.meta.total);
      setPageCount(l.meta.pageCount || 1);
      setFilterOptions({
        purchase_types: fo?.purchase_types ?? [],
        regions: fo?.regions ?? []
      });
      setTrackedCustomerNames(new Set((customers ?? []).map((c) => c.customer_name.trim().toLowerCase()).filter(Boolean)));
    } catch (e) {
      toast.error(`Ошибка загрузки: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setLoading(false);
    }
  }, [page, filterCustomer, filterType, filterRegion, filterDateFrom, filterDateTo, filterAmountMin, filterAmountMax, onlyOurParticipation, excludedMode]);
  reactExports.useEffect(() => {
    loadAll();
  }, [loadAll]);
  const handleSync = async () => {
    setSyncing(true);
    try {
      const r = await analyticsApi.sync();
      toast.success(`Синхронизация завершена: загружено ${r.fetched}, обновлено ${r.upserted}`);
      await loadAll();
    } catch (e) {
      toast.error(`Ошибка синхронизации: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setSyncing(false);
    }
  };
  const openEdit = (lot) => {
    setEditState({
      lot,
      winner_name: lot.winner_name || "",
      contract_amount: lot.contract_amount > 0 ? String(lot.contract_amount) : "",
      status: lot.status || ""
    });
  };
  const handleSave = async (data) => {
    if (!editState) return;
    setSaving(true);
    try {
      await analyticsApi.updateLot(editState.lot.id, data);
      setLots((prev) => prev.map((l) => l.id === editState.lot.id ? {
        ...l,
        winner_name: data.winner_name,
        contract_amount: data.contract_amount,
        status: data.status || l.status
      } : l));
      toast.success("Результаты сохранены");
      setEditState(null);
    } catch (e) {
      toast.error(`Ошибка сохранения: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setSaving(false);
    }
  };
  const handleTrackCustomer = async (lot) => {
    const name = lotCustomerName(lot);
    if (!name) return;
    try {
      await analyticsApi.addCustomer({
        customer_name: name,
        customer_id: lot.customer_id,
        notes: `Добавлен из истории тендеров: ${lot.title}`
      });
      setTrackedCustomerNames((prev) => new Set(prev).add(name.toLowerCase()));
      toast.success(`«${name}» добавлен в отслеживаемые заказчики`);
    } catch (e) {
      toast.error(`Не удалось добавить заказчика: ${e instanceof Error ? e.message : String(e)}`);
    }
  };
  const handleToggleExcluded = async (lot) => {
    try {
      if (lot.excluded_from_analytics) {
        await analyticsApi.restoreLot(lot.id);
        toast.success("Лот возвращён в аналитику");
      } else {
        await analyticsApi.excludeLot(lot.id);
        toast.success("Лот исключён из перерасчёта аналитики");
      }
      await loadAll();
    } catch (e) {
      toast.error(`Не удалось изменить лот: ${e instanceof Error ? e.message : String(e)}`);
    }
  };
  const applyFilters = () => {
    setPage(1);
  };
  const resetFilters = () => {
    setFilterCustomer("");
    setFilterType("");
    setFilterRegion("");
    setFilterDateFrom("");
    setFilterDateTo("");
    setFilterAmountMin("");
    setFilterAmountMax("");
    setOnlyOurParticipation(false);
    setExcludedMode("active");
    setPage(1);
  };
  const chartData = dynamics.map((d) => ({
    name: d.period,
    count: d.count,
    budget: +(d.budget / 1e6).toFixed(1)
  }));
  const lotCustomerName = (lot) => {
    return (lot.customer_name || lot.organizer_name || "").trim();
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { title: "История тендеров", description: "Аналитика закупочной деятельности", actions: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => setShowFilters((v) => !v), className: `inline-flex items-center gap-2 rounded-lg border border-border px-4 py-2 text-sm font-medium transition ${showFilters ? "bg-accent" : "bg-background hover:bg-accent"}`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: "h-4 w-4" }),
        " Фильтры"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => analyticsApi.exportCSV({
        customer: filterCustomer || void 0,
        purchase_type: filterType || void 0,
        region: filterRegion || void 0,
        date_from: filterDateFrom || void 0,
        date_to: filterDateTo || void 0,
        amount_min: filterAmountMin || void 0,
        amount_max: filterAmountMax || void 0,
        participation: onlyOurParticipation ? "our" : void 0,
        excluded: excludedMode === "only" ? "only" : void 0
      }), className: "inline-flex items-center gap-2 rounded-lg border border-border bg-background px-4 py-2 text-sm font-medium hover:bg-accent", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(FileSpreadsheet, { className: "h-4 w-4" }),
        " Excel"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: handleSync, disabled: syncing, className: "inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-50", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: `h-4 w-4 ${syncing ? "animate-spin" : ""}` }),
        syncing ? "Синхронизация…" : "Синхронизировать"
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6 p-8", children: [
      showFilters && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card p-5 shadow-sm animate-in slide-in-from-top-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "mb-4 text-sm font-semibold", children: "Параметры фильтрации" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: filterCustomer, onChange: (e) => setFilterCustomer(e.target.value), placeholder: "Поиск: название, заказчик, вид закупки", className: "rounded-lg border border-input bg-background px-3 py-2 text-sm" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("select", { value: filterType, onChange: (e) => setFilterType(e.target.value), className: "rounded-lg border border-input bg-background px-3 py-2 text-sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "", children: "Все виды закупки" }),
            filterOptions.purchase_types.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: t, children: t }, t))
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("select", { value: filterRegion, onChange: (e) => setFilterRegion(e.target.value), className: "rounded-lg border border-input bg-background px-3 py-2 text-sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "", children: "Все регионы" }),
            filterOptions.regions.map((r) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: r, children: r }, r))
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "date", value: filterDateFrom, onChange: (e) => setFilterDateFrom(e.target.value), className: "flex-1 rounded-lg border border-input bg-background px-3 py-2 text-sm" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "date", value: filterDateTo, onChange: (e) => setFilterDateTo(e.target.value), className: "flex-1 rounded-lg border border-input bg-background px-3 py-2 text-sm" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: filterAmountMin, onChange: (e) => setFilterAmountMin(e.target.value), placeholder: "Сумма от", className: "rounded-lg border border-input bg-background px-3 py-2 text-sm" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: filterAmountMax, onChange: (e) => setFilterAmountMax(e.target.value), placeholder: "Сумма до", className: "rounded-lg border border-input bg-background px-3 py-2 text-sm" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2 text-sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "checkbox", checked: onlyOurParticipation, onChange: (e) => setOnlyOurParticipation(e.target.checked), className: "rounded" }),
            "Только с нашим участием"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2 text-sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "checkbox", checked: excludedMode === "only", onChange: (e) => {
              setExcludedMode(e.target.checked ? "only" : "active");
              setPage(1);
            }, className: "rounded" }),
            "Показать исключённые"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: applyFilters, className: "rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90", children: "Применить" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: resetFilters, className: "rounded-lg border border-border bg-background px-4 py-2 text-sm font-medium hover:bg-accent", children: "Сбросить" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(StatCard, { label: "Всего тендеров", value: stats ? String(stats.total_lots) : "—", icon: Hash, accent: "bg-primary/10 text-primary" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(StatCard, { label: "Общий бюджет", value: stats ? `₸ ${fmtM(stats.total_budget)}` : "—", sub: stats ? `Ср. сделка: ₸ ${fmtM(stats.avg_amount)}` : void 0, icon: DollarSign, accent: "bg-green-100 text-green-600" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(StatCard, { label: "Ср. скидка", value: stats ? `${stats.avg_discount.toFixed(1)}%` : "—", sub: stats ? `Контрактов: ${stats.with_contract}` : void 0, icon: Percent, accent: "bg-orange-100 text-orange-600" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(StatCard, { label: "С победителем", value: stats ? String(stats.with_winner) : "—", sub: stats ? `Исключено: ${stats.excluded_lots ?? 0}` : void 0, icon: TrendingUp, accent: "bg-violet-100 text-violet-600" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 lg:grid-cols-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card p-6", style: {
          boxShadow: "var(--shadow-sm)"
        }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mb-1 text-sm font-semibold", children: "Количество тендеров по месяцам" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-4 text-xs text-muted-foreground", children: "Динамика за доступный период" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ResponsiveContainer, { width: "100%", height: 200, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(BarChart, { data: chartData, margin: {
            top: 0,
            right: 0,
            left: -20,
            bottom: 0
          }, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CartesianGrid, { strokeDasharray: "3 3", stroke: "var(--border)" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(XAxis, { dataKey: "name", tick: {
              fontSize: 11
            } }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(YAxis, { tick: {
              fontSize: 11
            } }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Tooltip, { formatter: (v) => [v, "Тендеров"] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Bar, { dataKey: "count", fill: "var(--primary)", radius: [4, 4, 0, 0] })
          ] }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card p-6", style: {
          boxShadow: "var(--shadow-sm)"
        }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mb-1 text-sm font-semibold", children: "Бюджет по месяцам (млн ₸)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-4 text-xs text-muted-foreground", children: "Суммарный объём закупок" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ResponsiveContainer, { width: "100%", height: 200, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(LineChart, { data: chartData, margin: {
            top: 0,
            right: 0,
            left: -20,
            bottom: 0
          }, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CartesianGrid, { strokeDasharray: "3 3", stroke: "var(--border)" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(XAxis, { dataKey: "name", tick: {
              fontSize: 11
            } }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(YAxis, { tick: {
              fontSize: 11
            } }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Tooltip, { formatter: (v) => [`${v} млн ₸`, "Бюджет"] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Line, { type: "monotone", dataKey: "budget", stroke: "var(--primary)", strokeWidth: 2, dot: {
              r: 3
            } })
          ] }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "overflow-hidden rounded-xl border border-border bg-card", style: {
        boxShadow: "var(--shadow-sm)"
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between border-b border-border px-6 py-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold", children: "Исторические тендеры" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-muted-foreground", children: [
              "Всего: ",
              total,
              " · Нажмите ",
              /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "inline h-3 w-3" }),
              " чтобы внести победителя и сумму контракта"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ChartNoAxesColumn, { className: "h-4 w-4 text-muted-foreground" })
        ] }),
        loading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-center py-16 text-sm text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mr-2 h-5 w-5 animate-spin rounded-full border-2 border-muted border-t-primary" }),
          "Загрузка…"
        ] }) : lots.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "py-16 text-center text-sm text-muted-foreground", children: filterCustomer.trim() || filterType || filterRegion || filterDateFrom || filterDateTo || filterAmountMin || filterAmountMax || onlyOurParticipation ? "По заданным фильтрам тендеры не найдены. Попробуйте другое название, заказчика или вид закупки." : "Нет данных — нажмите «Синхронизировать» для загрузки тендеров из TenderPlus" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full min-w-[1180px] text-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-left font-medium", children: "ID" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-left font-medium", children: "Наименование" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-left font-medium", children: "Заказчик / компания" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-left font-medium", children: "Регион / Площадка" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-right font-medium", children: "Нач. цена ₸" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-right font-medium", children: "Контракт ₸" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-left font-medium", children: "Победитель" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-left font-medium", children: "Дедлайн" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-left font-medium", children: "Статус" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-right font-medium", children: "Действия" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { children: lots.map((lot) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: `border-t border-border transition-colors ${lot.excluded_from_analytics ? "bg-muted/40 opacity-70" : "hover:bg-muted/30"}`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 font-mono text-xs text-muted-foreground", children: lot.lot_id }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "px-4 py-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-xs truncate font-medium text-foreground", children: lot.title }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-1 flex flex-wrap gap-1", children: [
                lot.purchase_type && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] text-muted-foreground", children: lot.purchase_type }),
                lot.excluded_from_analytics && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1 rounded-full bg-muted px-2 py-0.5 text-[10px] font-medium text-muted-foreground", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(EyeOff, { className: "h-3 w-3" }),
                  " исключён"
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex max-w-[220px] items-start gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className: "mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "truncate text-xs font-medium text-foreground", children: lotCustomerName(lot) || "—" }),
                lot.customer_id && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[11px] text-muted-foreground", children: [
                  "БИН/ИИН ",
                  lot.customer_id
                ] }),
                lotCustomerName(lot) && /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => handleTrackCustomer(lot), disabled: trackedCustomerNames.has(lotCustomerName(lot).toLowerCase()), className: "mt-1 inline-flex items-center gap-1 rounded-md border border-border px-2 py-0.5 text-[11px] text-muted-foreground hover:bg-accent disabled:cursor-default disabled:border-yellow-200 disabled:bg-yellow-50 disabled:text-yellow-700", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Star, { className: "h-3 w-3" }),
                  trackedCustomerNames.has(lotCustomerName(lot).toLowerCase()) ? "Отслеживается" : "Отслеживать"
                ] })
              ] })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "px-4 py-3 text-xs text-muted-foreground", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: lot.region || "—" }),
              lot.organizer_name && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] opacity-70", children: lot.organizer_name })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 text-right font-semibold tabular-nums", children: fmtN(lot.initial_amount) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 text-right tabular-nums", children: lot.contract_amount > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-green-700 font-medium", children: fmtN(lot.contract_amount) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground/40 text-xs italic", children: "не указана" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 max-w-[140px]", children: lot.winner_name ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate block text-xs font-medium text-foreground", children: lot.winner_name }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground/40 text-xs italic", children: "не указан" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 text-xs text-muted-foreground", children: fmtDate(lot.end_date) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `inline-flex rounded-full px-2 py-0.5 text-[11px] font-medium ${lot.status === "completed" ? "bg-gray-100 text-gray-600" : lot.status === "active" ? "bg-green-100 text-green-700" : lot.status === "cancelled" ? "bg-red-100 text-red-600" : "bg-blue-100 text-blue-700"}`, children: lot.status === "completed" ? "Завершён" : lot.status === "active" ? "Активный" : lot.status === "cancelled" ? "Отменён" : lot.status || "—" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-end gap-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => openEdit(lot), title: "Внести результат", className: "rounded-lg p-1.5 text-muted-foreground hover:bg-accent hover:text-foreground transition-colors", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-3.5 w-3.5" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => handleToggleExcluded(lot), title: lot.excluded_from_analytics ? "Вернуть в аналитику" : "Исключить из перерасчёта", className: "rounded-lg p-1.5 text-muted-foreground hover:bg-accent hover:text-foreground transition-colors", children: lot.excluded_from_analytics ? /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-3.5 w-3.5" }) })
            ] }) })
          ] }, lot.id)) })
        ] }) }),
        pageCount > 1 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between border-t border-border px-6 py-3 text-sm text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            "Стр. ",
            page,
            " из ",
            pageCount,
            " · всего: ",
            total
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setPage((p) => Math.max(1, p - 1)), disabled: page <= 1, className: "rounded-md border border-border p-1.5 hover:bg-accent disabled:opacity-40", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "h-4 w-4" }) }),
            Array.from({
              length: Math.min(5, pageCount)
            }, (_, i) => {
              const p = page <= 3 ? i + 1 : page - 2 + i;
              if (p < 1 || p > pageCount) return null;
              return /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setPage(p), className: `min-w-[32px] rounded-md px-2 py-1 text-sm ${p === page ? "bg-primary text-primary-foreground" : "border border-border hover:bg-accent"}`, children: p }, p);
            }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setPage((p) => Math.min(pageCount, p + 1)), disabled: page >= pageCount, className: "rounded-md border border-border p-1.5 hover:bg-accent disabled:opacity-40", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "h-4 w-4" }) })
          ] })
        ] })
      ] })
    ] }),
    editState && /* @__PURE__ */ jsxRuntimeExports.jsx(EditModal, { state: editState, onSave: handleSave, onClose: () => setEditState(null), saving }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(ToastContainer, { toasts: toast.toasts, onDismiss: toast.dismiss })
  ] });
}
export {
  HistoricalAnalytics as component
};
