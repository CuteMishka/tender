import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { d as useNavigate, L as Link } from "../_libs/tanstack__react-router.mjs";
import { P as PageHeader } from "./PageHeader-BgLmG3Y0.mjs";
import { f as formatTenderAmount, g as getLocalApiBase } from "./tenders-api-s2Iw9WUl.mjs";
import { u as useNotifications } from "./use-notifications-sQ8SQxfy.mjs";
import { G as Gavel, F as FileText, g as Building2, t as DollarSign, c as Bell, D as Download, f as ChevronRight, A as ArrowRight } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
const STATUS_RU = {
  active: {
    label: "Активный",
    cls: "bg-green-100 text-green-700"
  },
  participating: {
    label: "Участвуем",
    cls: "bg-blue-100 text-blue-700"
  },
  rejected: {
    label: "Отклонён",
    cls: "bg-red-100 text-red-600"
  }
};
function Dashboard() {
  const navigate = useNavigate();
  const {
    unreadCount
  } = useNotifications();
  const [dbStats, setDbStats] = reactExports.useState({
    active_count: 0,
    participating_count: 0,
    total_amount: 0,
    participating_amount: 0
  });
  const [savedLots, setSavedLots] = reactExports.useState([]);
  const [loading, setLoading] = reactExports.useState(true);
  reactExports.useEffect(() => {
    const base = getLocalApiBase();
    Promise.all([fetch(`${base}/api/v1/dashboard`).then((r) => r.json()).catch(() => null), fetch(`${base}/api/v1/lots/saved`).then((r) => r.json()).catch(() => [])]).then(([stats2, lots]) => {
      if (stats2 && !stats2.error) setDbStats(stats2);
      if (Array.isArray(lots)) setSavedLots(lots);
    }).finally(() => setLoading(false));
  }, []);
  const stats = [{
    label: "Активные тендеры",
    value: dbStats.active_count,
    display: String(dbStats.active_count),
    icon: Gavel,
    accent: "bg-primary/10 text-primary",
    border: "hover:border-primary/40",
    link: "/tenders"
  }, {
    label: "Участвуем тендеров",
    value: dbStats.participating_count,
    display: String(dbStats.participating_count),
    icon: FileText,
    accent: "bg-green-100 text-green-600",
    border: "hover:border-green-400/40",
    link: "/bids"
  }, {
    label: "Объём участвуем",
    value: dbStats.participating_amount,
    display: `₸ ${(dbStats.participating_amount / 1e6).toFixed(1)}М`,
    icon: Building2,
    accent: "bg-orange-100 text-orange-600",
    border: "hover:border-orange-400/40",
    link: "/bids"
  }, {
    label: "Объём контрактов (всего)",
    value: dbStats.total_amount,
    display: `₸ ${(dbStats.total_amount / 1e6).toFixed(1)}М`,
    icon: DollarSign,
    accent: "bg-violet-100 text-violet-600",
    border: "hover:border-violet-400/40",
    link: "/bids"
  }, {
    label: "Непрочитанных уведомлений",
    value: unreadCount,
    display: String(unreadCount),
    icon: Bell,
    accent: "bg-red-100 text-red-600",
    border: "hover:border-red-400/40",
    link: "/notifications"
  }];
  const last7Days = Array.from({
    length: 7
  }, (_, i) => {
    const d = /* @__PURE__ */ new Date();
    d.setDate(d.getDate() - (6 - i));
    d.setHours(0, 0, 0, 0);
    return d;
  });
  const dayCounts = last7Days.map((day) => {
    const nextDay = new Date(day);
    nextDay.setDate(nextDay.getDate() + 1);
    return savedLots.filter((lot) => {
      const d = new Date(lot.created_at);
      return d >= day && d < nextDay;
    }).length;
  });
  const maxCount = Math.max(...dayCounts, 1);
  const chartData = dayCounts.map((count, i) => ({
    count,
    height: count === 0 ? 4 : count / maxCount * 100,
    label: last7Days[i].toLocaleDateString("ru-RU", {
      weekday: "short"
    }).replace(".", "")
  }));
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { title: "Дашборд", description: "Обзор активности тендерной площадки", actions: /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "inline-flex items-center gap-2 rounded-lg border border-border bg-background px-4 py-2 text-sm font-medium hover:bg-accent", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "h-4 w-4" }),
      " Экспорт"
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6 p-8", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-4 md:grid-cols-2 xl:grid-cols-4", children: stats.map((s) => {
        const Icon = s.icon;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => navigate({
          to: s.link
        }), className: `group rounded-xl border border-border bg-card p-5 text-left transition ${s.border} hover:shadow-md`, style: {
          boxShadow: "var(--shadow-sm)"
        }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `flex h-10 w-10 items-center justify-center rounded-lg ${s.accent}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-5 w-5" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "h-4 w-4 text-muted-foreground/40 transition group-hover:translate-x-0.5 group-hover:text-muted-foreground" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-sm text-muted-foreground", children: s.label }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-2xl font-bold text-foreground", children: loading ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "inline-block h-7 w-16 animate-pulse rounded bg-muted" }) : s.display })
        ] }, s.label);
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card p-6", style: {
        boxShadow: "var(--shadow-sm)"
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-5 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-semibold", children: "Динамика заявок" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "Последние 7 дней" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/bids", className: "inline-flex items-center gap-1 text-xs font-medium text-primary hover:underline", children: [
            "Все заявки ",
            /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "h-3 w-3" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-48 items-end gap-2", children: chartData.map((d, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "group flex flex-1 flex-col items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "invisible text-xs font-medium text-foreground group-hover:visible", children: d.count }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full rounded-t-md transition-all duration-300 hover:opacity-75", style: {
            height: `${d.height}%`,
            background: "var(--gradient-primary, #16a34a)"
          } }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs uppercase tracking-wider text-muted-foreground", children: d.label })
        ] }, i)) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "overflow-hidden rounded-xl border border-border bg-card", style: {
        boxShadow: "var(--shadow-sm)"
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between border-b border-border px-6 py-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-semibold", children: "Последние тендеры" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "Тендеры в работе" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/tenders", search: {
            page: 1
          }, className: "inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline", children: [
            "Все тендеры ",
            /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "h-4 w-4" })
          ] })
        ] }),
        loading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-center py-16 text-sm text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-5 w-5 animate-spin rounded-full border-2 border-muted border-t-primary mr-2" }),
          "Загрузка…"
        ] }) : savedLots.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center justify-center py-16 text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Gavel, { className: "mb-3 h-10 w-10 opacity-20" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium", children: "Нет тендеров в работе" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs", children: "Нажмите «Подходит» на любом тендере, чтобы добавить его" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/tenders", search: {
            page: 1
          }, className: "mt-4 inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90", children: [
            "Перейти к тендерам ",
            /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "h-4 w-4" })
          ] })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "overflow-x-auto", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full min-w-[700px] text-sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3 text-left font-medium", children: "ID" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3 text-left font-medium", children: "Название" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3 text-left font-medium", children: "Вид закупа" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3 text-right font-medium", children: "Сумма" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3 text-left font-medium", children: "Дедлайн" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3 text-left font-medium", children: "Статус" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3" })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { children: savedLots.slice(0, 8).map((t) => {
              const deadlineDate = new Date(t.deadline);
              const diffDays = Math.ceil((deadlineDate.getTime() - Date.now()) / 864e5);
              const isExpiring = diffDays > 0 && diffDays <= 3;
              const s = STATUS_RU[t.status] ?? {
                label: t.status,
                cls: "bg-muted/40 text-muted-foreground"
              };
              return /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: `group cursor-pointer border-t border-border transition hover:bg-muted/40 ${isExpiring ? "bg-red-50/60" : ""}`, onClick: () => navigate({
                to: "/tenders/$tenderId",
                params: {
                  tenderId: String(t.id)
                }
              }), children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-6 py-4 font-mono text-xs text-muted-foreground", children: t.id }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-6 py-4 font-medium text-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "line-clamp-1 max-w-xs", children: t.title }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-6 py-4 text-xs text-muted-foreground", children: t.purchase_type || "—" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "px-6 py-4 text-right font-semibold tabular-nums", children: [
                  "₸ ",
                  formatTenderAmount(t.amount)
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "px-6 py-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-xs ${isExpiring ? "font-semibold text-red-600" : "text-muted-foreground"}`, children: deadlineDate.toLocaleDateString("ru-KZ") }),
                  isExpiring && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "ml-1.5 rounded-full bg-red-100 px-1.5 py-0.5 text-[10px] font-semibold text-red-600", children: [
                    diffDays,
                    " дн."
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-6 py-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `inline-flex rounded-full px-2.5 py-1 text-xs font-medium ${s.cls}`, children: s.label }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-6 py-4 text-right", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "h-4 w-4 text-muted-foreground/30 transition group-hover:text-muted-foreground" }) })
              ] }, t.id);
            }) })
          ] }),
          savedLots.length > 8 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "border-t border-border px-6 py-3 text-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/bids", className: "text-sm font-medium text-primary hover:underline", children: [
            "Показать ещё ",
            savedLots.length - 8,
            " →"
          ] }) })
        ] })
      ] })
    ] })
  ] });
}
export {
  Dashboard as component
};
