import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { d as useNavigate } from "../_libs/tanstack__react-router.mjs";
import { P as PageHeader } from "./PageHeader-BgLmG3Y0.mjs";
import { g as getLocalApiBase } from "./tenders-api-s2Iw9WUl.mjs";
import { l as Search, F as FileText, w as CircleX, n as Clock, x as CircleCheck, k as Trash2 } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
const statusMap = {
  participating: {
    label: "Участвуем",
    icon: CircleCheck,
    cls: "bg-primary/15 text-primary"
  },
  active: {
    label: "Открыт",
    icon: Clock,
    cls: "bg-success/15 text-success"
  },
  rejected: {
    label: "Отклонен",
    icon: CircleX,
    cls: "bg-destructive/15 text-destructive"
  }
};
function Bids() {
  const navigate = useNavigate();
  const [bids, setBids] = reactExports.useState([]);
  const [activeTab, setActiveTab] = reactExports.useState("all");
  const [searchText, setSearchText] = reactExports.useState("");
  reactExports.useEffect(() => {
    const base = getLocalApiBase();
    fetch(`${base}/api/v1/lots/saved`).then((res) => res.json()).then((data) => {
      if (Array.isArray(data)) setBids(data);
    }).catch((err) => console.error(err));
  }, []);
  const handleDelete = async (id) => {
    if (!confirm("Вы уверены, что хотите удалить этот тендер из заявок?")) return;
    try {
      const res = await fetch(`${getLocalApiBase()}/api/v1/lots/saved/${id}`, {
        method: "DELETE"
      });
      if (!res.ok) throw new Error("Ошибка при удалении");
      setBids((prev) => prev.filter((b) => b.id !== id));
    } catch (err) {
      console.error(err);
      alert("Не удалось удалить заявку");
    }
  };
  const filteredBids = bids.filter((b) => {
    if (activeTab !== "all" && b.status !== activeTab) return false;
    const q = searchText.trim().toLowerCase();
    if (!q) return true;
    return `${b.id} ${b.title} ${b.organizer_name} ${b.purchase_type} ${b.status}`.toLowerCase().includes(q);
  });
  const tabCounts = {
    all: bids.length,
    participating: bids.filter((b) => b.status === "participating").length,
    active: bids.filter((b) => b.status === "active").length,
    rejected: bids.filter((b) => b.status === "rejected").length
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { title: "Заявки", description: "Все заявки участников на тендеры" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-8", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-4 flex flex-wrap items-center gap-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative min-w-[260px] flex-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: searchText, onChange: (e) => setSearchText(e.target.value), placeholder: "Поиск по названию, организатору, виду закупки...", className: "w-full rounded-lg border border-input bg-background py-2 pl-9 pr-3 text-sm" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-4 flex flex-wrap gap-2", children: [{
        key: "all",
        label: "Все"
      }, {
        key: "participating",
        label: "Наше участие"
      }, {
        key: "active",
        label: "Активные"
      }, {
        key: "rejected",
        label: "Не подходит"
      }].map((tab) => /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => setActiveTab(tab.key), className: `inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-sm font-medium transition ${activeTab === tab.key ? "bg-primary text-primary-foreground" : "border border-border bg-card hover:bg-accent"}`, children: [
        tab.label,
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `rounded-full px-1.5 py-0.5 text-[10px] font-medium ${activeTab === tab.key ? "bg-primary-foreground/20" : "bg-muted text-muted-foreground"}`, children: tabCounts[tab.key] })
      ] }, tab.key)) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-hidden rounded-xl border border-border bg-card", style: {
        boxShadow: "var(--shadow-sm)"
      }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-sm", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3 text-left font-medium", children: "ID заявки" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3 text-left font-medium", children: "Тендер" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3 text-left font-medium", children: "Наименование тендера" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3 text-left font-medium", children: "Организатор тендера" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3 text-left font-medium", children: "Цена ₸" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3 text-left font-medium", children: "Дата" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3 text-left font-medium", children: "Статус" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3 text-right font-medium", children: "Действия" })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("tbody", { children: [
          filteredBids.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("td", { colSpan: 8, className: "px-6 py-16 text-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center gap-2 text-muted-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(FileText, { className: "h-10 w-10 opacity-20" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium", children: searchText.trim() ? "По названию, организатору или виду закупки заявки не найдены" : activeTab === "all" ? "Заявок пока нет" : `Нет заявок со статусом «${{
              all: "",
              participating: "Наше участие",
              active: "Активные",
              rejected: "Не подходит"
            }[activeTab]}»` }),
            activeTab === "all" && !searchText.trim() && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs", children: "Отметьте тендер кнопкой «Подходит» во вкладке Тендеры" })
          ] }) }) }),
          filteredBids.map((b) => {
            const s = statusMap[b.status] || statusMap.active;
            const Icon = s.icon;
            const dateStr = new Date(b.created_at).toLocaleDateString("ru-KZ");
            const amountStr = new Intl.NumberFormat("ru-KZ").format(b.amount);
            return /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "cursor-pointer border-t border-border hover:bg-muted/40", onClick: () => navigate({
              to: "/tenders/$tenderId",
              params: {
                tenderId: String(b.id)
              }
            }), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "px-6 py-4 font-mono text-xs text-muted-foreground", children: [
                "B-",
                b.id
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "px-6 py-4 font-mono text-xs font-medium text-primary", children: [
                "T-",
                b.id
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-6 py-4 font-medium text-foreground", children: b.title }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-6 py-4 font-medium text-foreground", children: b.organizer_name || "Компания не указана" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "px-6 py-4 text-right font-semibold tabular-nums", children: [
                "₸ ",
                amountStr
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-6 py-4 text-muted-foreground", children: dateStr }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-6 py-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ${s.cls}`, children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-3 w-3" }),
                " ",
                s.label
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-6 py-4 text-right", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: (e) => {
                e.stopPropagation();
                handleDelete(b.id);
              }, className: "inline-flex items-center gap-1 rounded-lg border border-border px-2.5 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:border-destructive/30 hover:bg-destructive/10 hover:text-destructive", title: "Удалить заявку", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }),
                "Удалить"
              ] }) })
            ] }, b.id);
          })
        ] })
      ] }) })
    ] })
  ] });
}
export {
  Bids as component
};
