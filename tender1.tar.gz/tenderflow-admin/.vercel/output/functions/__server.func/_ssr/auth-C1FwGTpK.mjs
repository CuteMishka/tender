const AUTH_KEY = "tender_admin_auth";
const isAuthenticated = () => {
  if (typeof window === "undefined") return false;
  return localStorage.getItem(AUTH_KEY) === "true";
};
const login = (username, password) => {
  if (username === "admin" && password === "admin") {
    localStorage.setItem(AUTH_KEY, "true");
    return true;
  }
  return false;
};
const logout = () => {
  localStorage.removeItem(AUTH_KEY);
};
export {
  logout as a,
  isAuthenticated as i,
  login as l
};
