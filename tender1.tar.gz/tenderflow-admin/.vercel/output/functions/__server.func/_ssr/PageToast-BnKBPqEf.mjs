import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { X, a4 as Info, a as CircleAlert, w as CircleX, x as CircleCheck } from "../_libs/lucide-react.mjs";
const icons = {
  success: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "h-4 w-4 text-green-600 shrink-0" }),
  error: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleX, { className: "h-4 w-4 text-destructive shrink-0" }),
  warning: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "h-4 w-4 text-yellow-600 shrink-0" }),
  info: /* @__PURE__ */ jsxRuntimeExports.jsx(Info, { className: "h-4 w-4 text-blue-600 shrink-0" })
};
const colors = {
  success: "border-green-200 bg-green-50 text-green-900",
  error: "border-red-200 bg-red-50 text-red-900",
  warning: "border-yellow-200 bg-yellow-50 text-yellow-900",
  info: "border-blue-200 bg-blue-50 text-blue-900"
};
function ToastItem({ toast, onDismiss }) {
  const [visible, setVisible] = reactExports.useState(false);
  reactExports.useEffect(() => {
    const t1 = setTimeout(() => setVisible(true), 10);
    const t2 = setTimeout(() => {
      setVisible(false);
      setTimeout(() => onDismiss(toast.id), 300);
    }, 3500);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, [toast.id, onDismiss]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      className: `flex items-center gap-2.5 rounded-lg border px-4 py-3 text-sm shadow-lg transition-all duration-300 ${colors[toast.type]} ${visible ? "translate-y-0 opacity-100" : "translate-y-2 opacity-0"}`,
      children: [
        icons[toast.type],
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex-1", children: toast.message }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: () => onDismiss(toast.id),
            className: "ml-1 rounded p-0.5 opacity-60 hover:opacity-100",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-3.5 w-3.5" })
          }
        )
      ]
    }
  );
}
function ToastContainer({ toasts, onDismiss }) {
  if (toasts.length === 0) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed bottom-6 right-6 z-50 flex flex-col gap-2 w-80", children: toasts.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx(ToastItem, { toast: t, onDismiss }, t.id)) });
}
function useToast() {
  const [toasts, setToasts] = reactExports.useState([]);
  const show = (type, message) => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    setToasts((prev) => [...prev, { id, type, message }]);
  };
  const dismiss = (id) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };
  return {
    toasts,
    dismiss,
    success: (msg) => show("success", msg),
    error: (msg) => show("error", msg),
    warning: (msg) => show("warning", msg),
    info: (msg) => show("info", msg)
  };
}
export {
  ToastContainer as T,
  useToast as u
};
