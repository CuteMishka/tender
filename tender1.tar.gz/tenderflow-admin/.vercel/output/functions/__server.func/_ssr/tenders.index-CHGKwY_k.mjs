import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { e as useLocation, d as useNavigate, L as Link } from "../_libs/tanstack__react-router.mjs";
import { P as PageHeader } from "./PageHeader-BgLmG3Y0.mjs";
import { a as getViewedTenders, b as getAllViewInfo, g as getLocalApiBase, c as fetchTendersList, d as getTenderStatus, t as tenderCompanyName, f as formatTenderAmount, e as formatDate, s as sanitizeApiText } from "./tenders-api-s2Iw9WUl.mjs";
import { p as pushNotification } from "./use-notifications-sQ8SQxfy.mjs";
import { y as Funnel, x as CircleCheck, E as ExternalLink, z as ThumbsUp, I as ThumbsDown } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
function pageFromLocation(location) {
  const s = location.search;
  if (typeof s === "object" && s !== null && "page" in s) {
    const p2 = Number(s.page);
    if (Number.isFinite(p2) && p2 >= 1) return Math.floor(p2);
  }
  const raw = location.searchStr ?? "";
  const q = new URLSearchParams(raw.startsWith("?") ? raw.slice(1) : raw);
  const p = Number(q.get("page"));
  return Number.isFinite(p) && p >= 1 ? Math.floor(p) : 1;
}
function truncate(s, max) {
  const t = sanitizeApiText(s);
  if (t.length <= max) return t;
  return `${t.slice(0, max - 1)}…`;
}
function isGovernmentProcurementQuery(s) {
  const q = s.trim().toLowerCase();
  return q.includes("государствен") || q.includes("гос закуп") || q.includes("госзакуп");
}
const statusColorMap = {
  green: "bg-green-100 text-green-700",
  orange: "bg-orange-100 text-orange-700",
  red: "bg-red-100 text-red-700",
  gray: "bg-muted/50 text-muted-foreground"
};
async function saveLot(tender, status) {
  const deadline = tender.endDate ? new Date(tender.endDate).toISOString() : new Date(Date.now() + 30 * 24 * 60 * 60 * 1e3).toISOString();
  const payload = {
    id: tender.id,
    title: tender.title || "Без названия",
    description: tender.description || "",
    amount: tender.cost || 0,
    status,
    deadline,
    start_date: tender.startDate ? new Date(tender.startDate).toISOString() : (/* @__PURE__ */ new Date()).toISOString(),
    end_date: deadline,
    purchase_type: tender.purchaseType || "—",
    organizer_name: tenderCompanyName(tender),
    partner_link: tender.partnerLink || ""
  };
  const res = await fetch(`${getLocalApiBase()}/api/v1/lots/participate`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });
  if (!res.ok) throw new Error("Ошибка при сохранении");
}
function TendersList() {
  const location = useLocation();
  const navigate = useNavigate();
  const page = pageFromLocation(location);
  const [data, setData] = reactExports.useState(null);
  const [error, setError] = reactExports.useState(null);
  const [loading, setLoading] = reactExports.useState(true);
  const [actionLoading, setActionLoading] = reactExports.useState(null);
  const [viewedIds, setViewedIds] = reactExports.useState(() => getViewedTenders());
  const [viewInfoMap, setViewInfoMap] = reactExports.useState(() => getAllViewInfo());
  const [activeTab, setActiveTab] = reactExports.useState("Все");
  const [showFilters, setShowFilters] = reactExports.useState(false);
  const [searchText, setSearchText] = reactExports.useState("");
  const [filterMinAmount, setFilterMinAmount] = reactExports.useState("");
  const [filterMaxAmount, setFilterMaxAmount] = reactExports.useState("");
  const [savedIds, setSavedIds] = reactExports.useState(/* @__PURE__ */ new Set());
  reactExports.useEffect(() => {
    fetch(`${getLocalApiBase()}/api/v1/lots/saved`).then((r) => r.json()).then((d) => {
      if (Array.isArray(d)) setSavedIds(new Set(d.filter((l) => l.status === "participating").map((l) => l.id)));
    }).catch(() => {
    });
  }, []);
  reactExports.useEffect(() => {
    const refresh = () => {
      setViewedIds(getViewedTenders());
      setViewInfoMap(getAllViewInfo());
    };
    window.addEventListener("focus", refresh);
    return () => window.removeEventListener("focus", refresh);
  }, []);
  reactExports.useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    const keywords = isGovernmentProcurementQuery(searchText) ? "" : searchText;
    fetchTendersList({
      page,
      limit: 10,
      keywords
    }).then((d) => {
      if (!cancelled) setData(d);
    }).catch((e) => {
      if (!cancelled) setError(e instanceof Error ? e.message : String(e));
    }).finally(() => {
      if (!cancelled) setLoading(false);
    });
    return () => {
      cancelled = true;
    };
  }, [page, searchText]);
  const filteredItems = (data?.items ?? []).filter((t) => {
    const status = getTenderStatus(t.endDate);
    if (activeTab === "Активные" && status.color === "gray") return false;
    if (activeTab === "Истекающие" && status.color !== "red" && status.color !== "orange") return false;
    if (activeTab === "Завершённые" && status.color !== "gray") return false;
    if (activeTab === "Наше участие" && !savedIds.has(t.id)) return false;
    const minA = parseFloat(filterMinAmount);
    const maxA = parseFloat(filterMaxAmount);
    if (!isNaN(minA) && t.cost < minA) return false;
    if (!isNaN(maxA) && t.cost > maxA) return false;
    return true;
  });
  const handleAction = async (e, tender, status) => {
    e.stopPropagation();
    setActionLoading(tender.id);
    try {
      await saveLot(tender, status);
      if (status === "participating") {
        pushNotification("success", "Участвуем", `Тендер «${truncate(tender.title, 60)}» добавлен в заявки.`, "/bids");
      } else {
        pushNotification("info", "Не подходит", `Тендер «${truncate(tender.title, 60)}» отклонён.`);
      }
    } catch {
      pushNotification("error", "Ошибка", "Не удалось обновить статус тендера.");
    } finally {
      setActionLoading(null);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { title: "Тендеры", actions: /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => setShowFilters(!showFilters), className: `inline-flex items-center gap-2 rounded-lg border border-border px-4 py-2 text-sm font-medium transition-colors ${showFilters ? "bg-accent text-accent-foreground" : "bg-background hover:bg-accent"}`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { className: "h-4 w-4" }),
      " Фильтры"
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-8", children: [
      showFilters && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-6 rounded-xl border border-border bg-card p-5 shadow-sm animate-in slide-in-from-top-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "mb-4 text-sm font-medium", children: "Параметры фильтрации" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 sm:grid-cols-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "text", placeholder: "Поиск по названию, заказчику, виду закупки...", value: searchText, onChange: (e) => {
            setSearchText(e.target.value);
            if (page !== 1) {
              navigate({
                to: "/tenders",
                search: {
                  page: 1
                }
              });
            }
          }, className: "rounded-lg border border-input bg-background px-3 py-2.5 text-sm" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "number", placeholder: "Мин. сумма ₸", value: filterMinAmount, onChange: (e) => setFilterMinAmount(e.target.value), className: "rounded-lg border border-input bg-background px-3 py-2.5 text-sm" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "number", placeholder: "Макс. сумма ₸", value: filterMaxAmount, onChange: (e) => setFilterMaxAmount(e.target.value), className: "rounded-lg border border-input bg-background px-3 py-2.5 text-sm" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-4 flex flex-wrap gap-2", children: [{
        key: "Все",
        count: data?.items?.length
      }, {
        key: "Активные"
      }, {
        key: "Истекающие"
      }, {
        key: "Завершённые"
      }, {
        key: "Наше участие",
        count: savedIds.size,
        icon: CircleCheck
      }].map(({
        key: tab,
        count,
        icon: Icon
      }) => /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => setActiveTab(tab), className: `inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-sm font-medium transition ${activeTab === tab ? "bg-primary text-primary-foreground" : "border border-border bg-card text-foreground hover:bg-accent"}`, children: [
        Icon && /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-3.5 w-3.5" }),
        tab,
        count !== void 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `rounded-full px-1.5 py-0.5 text-[10px] font-medium ${activeTab === tab ? "bg-primary-foreground/20" : "bg-muted text-muted-foreground"}`, children: count })
      ] }, tab)) }),
      error ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-4 rounded-xl border border-destructive/30 bg-destructive/10 px-6 py-4 text-sm text-destructive", children: error }) : null,
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-hidden rounded-xl border border-border bg-card", style: {
        boxShadow: "var(--shadow-sm)"
      }, children: loading && !data ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-center px-6 py-24 text-sm text-muted-foreground", children: "Загрузка…" }) : data ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full min-w-[1100px] text-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-left font-medium", children: "ID / закупка" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-left font-medium", children: "Лот / источник" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-left font-medium", children: "Тендер" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-right font-medium", children: "Сумма ₸" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-left font-medium", children: "Дедлайн" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-left font-medium", children: "Статус" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-center font-medium", children: "Ссылка" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 text-center font-medium", children: "Действия" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("tbody", { children: [
            filteredItems.map((t) => {
              const statusInfo = getTenderStatus(t.endDate);
              const isExpiring = statusInfo.color === "red";
              const isLoading = actionLoading === t.id;
              const companyName = tenderCompanyName(t);
              return /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { role: "link", tabIndex: 0, className: `cursor-pointer border-t border-border transition hover:bg-muted/40 ${isExpiring ? "bg-red-50/60" : ""}`, onClick: () => navigate({
                to: "/tenders/$tenderId",
                params: {
                  tenderId: String(t.id)
                },
                state: (prev) => ({
                  ...prev,
                  tendersPage: page
                })
              }), onKeyDown: (e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  navigate({
                    to: "/tenders/$tenderId",
                    params: {
                      tenderId: String(t.id)
                    },
                    state: (prev) => ({
                      ...prev,
                      tendersPage: page
                    })
                  });
                }
              }, children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "px-4 py-4 font-mono text-xs text-muted-foreground", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: t.id }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-0.5 text-[10px] text-muted-foreground/80", children: [
                    "buy_id ",
                    t.buy_id
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "px-4 py-4 font-mono text-xs text-foreground", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: t.lot }),
                  t.lot_source_id && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-0.5 text-[10px] text-muted-foreground", children: t.lot_source_id })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "px-4 py-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "max-w-sm font-medium text-foreground", children: truncate(t.title, 100) }),
                    viewedIds.has(t.id) && (() => {
                      const vi = viewInfoMap[String(t.id)];
                      return /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "shrink-0 inline-flex items-center gap-1 rounded-full bg-muted px-2 py-0.5 text-[10px] font-medium text-muted-foreground", children: [
                        "Просмотрено",
                        vi?.viewer ? ` (${vi.viewer})` : "",
                        vi?.decision === "participating" && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rounded-full bg-green-100 px-1.5 py-px text-[9px] font-semibold text-green-700", children: "Участвуем" }),
                        vi?.decision === "rejected" && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rounded-full bg-red-100 px-1.5 py-px text-[9px] font-semibold text-red-600", children: "Отклонён" })
                      ] });
                    })()
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-1 max-w-sm text-xs font-medium text-foreground/80", children: companyName || "Компания не указана" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-1 max-w-sm text-xs text-muted-foreground", children: truncate(t.description, 120) })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-4 text-right font-semibold tabular-nums", children: formatTenderAmount(t.cost) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-4 text-xs text-muted-foreground", children: t.endDate ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `font-medium ${isExpiring ? "text-red-600" : ""}`, children: formatDate(t.endDate).split(",")[0] }),
                  statusInfo.daysLeft !== null && statusInfo.daysLeft >= 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `text-[10px] ${isExpiring ? "text-red-500 font-semibold" : "text-muted-foreground"}`, children: statusInfo.daysLeft === 0 ? "сегодня" : `${statusInfo.daysLeft} дн.` })
                ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground/60", children: "—" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium ${statusColorMap[statusInfo.color]}`, children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `h-1.5 w-1.5 rounded-full ${statusInfo.color === "green" ? "bg-green-500" : statusInfo.color === "orange" ? "bg-orange-500" : statusInfo.color === "red" ? "bg-red-500" : "bg-muted-foreground"}` }),
                  statusInfo.label
                ] }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-4 text-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: t.partnerLink, target: "_blank", rel: "noopener noreferrer", className: "inline-flex rounded-md p-2 text-primary hover:bg-accent", title: "Открыть на площадке", onClick: (e) => e.stopPropagation(), children: /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "h-4 w-4" }) }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-center gap-1", onClick: (e) => e.stopPropagation(), children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("button", { disabled: isLoading, onClick: (e) => handleAction(e, t, "participating"), title: "Подходит — участвуем", className: "inline-flex rounded-lg border border-green-200 bg-green-50 px-2.5 py-1.5 text-xs font-medium text-green-700 transition hover:bg-green-100 disabled:opacity-50", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ThumbsUp, { className: "h-3.5 w-3.5" }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("button", { disabled: isLoading, onClick: (e) => handleAction(e, t, "rejected"), title: "Не подходит", className: "inline-flex rounded-lg border border-red-200 bg-red-50 px-2.5 py-1.5 text-xs font-medium text-red-600 transition hover:bg-red-100 disabled:opacity-50", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ThumbsDown, { className: "h-3.5 w-3.5" }) })
                ] }) })
              ] }, t.id);
            }),
            filteredItems.length === 0 && !loading && /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("td", { colSpan: 8, className: "px-6 py-16 text-center text-sm text-muted-foreground", children: searchText.trim() ? "По названию, заказчику или виду закупки тендеры не найдены. Попробуйте другое слово или сбросьте фильтр." : "Тендеры не найдены" }) })
          ] })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3 border-t border-border px-6 py-3 text-sm text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            "Стр. ",
            page,
            " из ",
            Math.max(1, data.meta.pageCount || 1),
            " · записей: ",
            filteredItems.length,
            " · всего: ",
            data.meta.totalCount,
            loading ? " · обновление…" : ""
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/tenders", search: {
              page: Math.max(1, page - 1)
            }, className: `rounded-md border border-border px-3 py-1 hover:bg-accent ${page <= 1 ? "pointer-events-none opacity-40" : ""}`, children: "←" }),
            Array.from({
              length: Math.max(1, data.meta.pageCount || 1)
            }, (_, i) => i + 1).map((p) => /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/tenders", search: {
              page: p
            }, className: `rounded-md px-3 py-1 ${p === page ? "bg-primary text-primary-foreground" : "border border-border hover:bg-accent"}`, children: p }, p)),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/tenders", search: {
              page: Math.min(Math.max(1, data.meta.pageCount || 1), page + 1)
            }, className: `rounded-md border border-border px-3 py-1 hover:bg-accent ${page >= (data.meta.pageCount || 1) ? "pointer-events-none opacity-40" : ""}`, children: "→" })
          ] })
        ] })
      ] }) : null })
    ] })
  ] });
}
export {
  TendersList as component
};
