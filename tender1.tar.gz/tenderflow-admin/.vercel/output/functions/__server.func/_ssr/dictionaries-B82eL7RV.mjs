import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { P as PageHeader } from "./PageHeader-BgLmG3Y0.mjs";
import { l as Search, p as Plus, D as Download, q as Check, r as Save, X, s as Pen, k as Trash2 } from "../_libs/lucide-react.mjs";
const tabs = [{
  key: "advantages",
  label: "Преимущества",
  hint: "Что усиливает релевантность тендера",
  seed: ["Информационная безопасность", "SOC", "DLP", "NGFW"]
}, {
  key: "blockers",
  label: "Блокеры",
  hint: "Что исключает тендер на этапе парсинга",
  seed: ["Строительные работы", "Поставка мебели", "Медицинское оборудование"]
}, {
  key: "keywords",
  label: "Ключевые слова",
  hint: "Слова для поиска тендеров и парсера",
  seed: ["кибербезопасность", "ОЦИБ", "EDR", "пентест", "аудит безопасности"]
}, {
  key: "tru",
  label: "ТРУ коды",
  hint: "Коды товаров/работ/услуг для будущего парсера",
  seed: ["620920.000.000000", "631111.000.000000", "749020.000.000000"]
}, {
  key: "companies",
  label: "Компании / BIN",
  hint: "Наши компании, конкуренты и заказчики",
  seed: ["Freedom Cloud", "CitizenSec", "ТОО пример / 123456789012"]
}];
const storageKey = "parser_dictionaries_v1";
function createItem(value) {
  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    value,
    active: true
  };
}
function seedData() {
  return Object.fromEntries(tabs.map((tab) => [tab.key, tab.seed.map(createItem)]));
}
function loadData() {
  try {
    const raw = localStorage.getItem(storageKey);
    if (!raw) return seedData();
    const parsed = JSON.parse(raw);
    const seeded = seedData();
    for (const tab of tabs) seeded[tab.key] = Array.isArray(parsed[tab.key]) ? parsed[tab.key] : seeded[tab.key];
    return seeded;
  } catch {
    return seedData();
  }
}
function saveData(data) {
  localStorage.setItem(storageKey, JSON.stringify(data));
}
function DictionariesPage() {
  const [data, setData] = reactExports.useState(loadData);
  const [active, setActive] = reactExports.useState("keywords");
  const [draft, setDraft] = reactExports.useState("");
  const [searchText, setSearchText] = reactExports.useState("");
  const [editingId, setEditingId] = reactExports.useState(null);
  const [editingValue, setEditingValue] = reactExports.useState("");
  reactExports.useEffect(() => saveData(data), [data]);
  const activeTab = tabs.find((tab) => tab.key === active);
  const items = data[active];
  const visibleItems = items.filter((item) => {
    const q = searchText.trim().toLowerCase();
    if (!q) return true;
    return `${item.value} ${item.lastLot ?? ""} ${item.active ? "вкл активно" : "выкл неактивно"}`.toLowerCase().includes(q);
  });
  const totals = reactExports.useMemo(() => Object.fromEntries(tabs.map((tab) => [tab.key, {
    total: data[tab.key].length,
    active: data[tab.key].filter((i) => i.active).length
  }])), [data]);
  const exportCSV = () => {
    const rows = items.map((item, i) => `${i + 1},"${item.value.replace(/"/g, '""')}",${item.active ? "Вкл" : "Выкл"},"${item.lastLot || ""}"`);
    const csv = `#,Значение,Статус,Последний лот
${rows.join("\n")}`;
    const blob = new Blob(["\uFEFF" + csv], {
      type: "text/csv;charset=utf-8;"
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${activeTab.label}_${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };
  const add = () => {
    const value = draft.trim();
    if (!value) return;
    setData((prev) => ({
      ...prev,
      [active]: [...prev[active], createItem(value)]
    }));
    setDraft("");
  };
  const remove = (id) => {
    setData((prev) => ({
      ...prev,
      [active]: prev[active].filter((item) => item.id !== id)
    }));
  };
  const toggle = (id) => {
    setData((prev) => ({
      ...prev,
      [active]: prev[active].map((item) => item.id === id ? {
        ...item,
        active: !item.active
      } : item)
    }));
  };
  const startEdit = (item) => {
    setEditingId(item.id);
    setEditingValue(item.value);
  };
  const saveEdit = () => {
    if (!editingId) return;
    const value = editingValue.trim();
    if (!value) return;
    setData((prev) => ({
      ...prev,
      [active]: prev[active].map((item) => item.id === editingId ? {
        ...item,
        value
      } : item)
    }));
    setEditingId(null);
    setEditingValue("");
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { title: "Справочники", description: "Преимущества, блокеры, ключевые слова, ТРУ коды и переменные для будущего парсера", actions: /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setData(seedData()), className: "rounded-lg border border-border bg-background px-4 py-2 text-sm font-medium hover:bg-accent", children: "Сбросить демо" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5 p-8", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: tabs.map((tab) => {
        const t = totals[tab.key];
        return /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => setActive(tab.key), className: `inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-sm font-medium transition ${active === tab.key ? "bg-primary text-primary-foreground" : "border border-border bg-card hover:bg-accent"}`, children: [
          tab.label,
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `rounded-full px-1.5 py-0.5 text-[10px] font-medium ${active === tab.key ? "bg-primary-foreground/20" : "bg-muted text-muted-foreground"}`, children: [
            t.active,
            "/",
            t.total
          ] })
        ] }, tab.key);
      }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card", style: {
        boxShadow: "var(--shadow-sm)"
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3 border-b border-border px-6 py-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-semibold", children: activeTab.label }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: activeTab.hint })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative min-w-[240px]", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: searchText, onChange: (e) => setSearchText(e.target.value), placeholder: "Поиск по справочнику", className: "w-full rounded-lg border border-input bg-background py-2 pl-9 pr-3 text-sm" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex min-w-[280px] flex-1 gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: draft, onChange: (e) => setDraft(e.target.value), onKeyDown: (e) => {
                if (e.key === "Enter") add();
              }, placeholder: "Добавить значение", className: "min-w-0 flex-1 rounded-lg border border-input bg-background px-3 py-2 text-sm" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: add, className: "inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4" }),
                " Добавить"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: exportCSV, title: "Експорт в CSV", className: "inline-flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2 text-sm font-medium hover:bg-accent", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "h-4 w-4" }),
              " CSV"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full min-w-[760px] text-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3 text-left font-medium", children: "#" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3 text-left font-medium", children: "Значение" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3 text-left font-medium", children: "Активно" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3 text-left font-medium", children: "Последний лот" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3 text-right font-medium", children: "Действия" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("tbody", { children: [
            visibleItems.map((item, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-t border-border hover:bg-muted/30", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-6 py-3 font-mono text-xs text-muted-foreground", children: i + 1 }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-6 py-3", children: editingId === item.id ? /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: editingValue, onChange: (e) => setEditingValue(e.target.value), className: "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-foreground", children: item.value }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-6 py-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => toggle(item.id), className: `inline-flex items-center gap-1 rounded-full px-2 py-1 text-xs ${item.active ? "bg-green-100 text-green-700" : "bg-muted text-muted-foreground"}`, children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "h-3 w-3" }),
                " ",
                item.active ? "Вкл" : "Выкл"
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-6 py-3 text-xs text-muted-foreground", children: item.lastLot || "—" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-6 py-3 text-right", children: editingId === item.id ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex gap-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: saveEdit, className: "rounded-lg p-2 text-green-700 hover:bg-green-100", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Save, { className: "h-4 w-4" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setEditingId(null), className: "rounded-lg p-2 text-muted-foreground hover:bg-accent", children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4" }) })
              ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex gap-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => startEdit(item), className: "rounded-lg p-2 text-muted-foreground hover:bg-accent hover:text-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Pen, { className: "h-4 w-4" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => remove(item.id), className: "rounded-lg p-2 text-muted-foreground hover:bg-destructive/10 hover:text-destructive", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) })
              ] }) })
            ] }, item.id)),
            visibleItems.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("td", { colSpan: 5, className: "px-6 py-12 text-center text-sm text-muted-foreground", children: "По справочнику ничего не найдено" }) })
          ] })
        ] }) })
      ] })
    ] })
  ] });
}
export {
  DictionariesPage as component
};
