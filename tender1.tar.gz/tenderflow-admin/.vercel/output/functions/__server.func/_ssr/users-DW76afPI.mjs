import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { P as PageHeader } from "./PageHeader-BgLmG3Y0.mjs";
import { g as getLocalApiBase } from "./tenders-api-s2Iw9WUl.mjs";
import { l as Search } from "../_libs/lucide-react.mjs";
const users = [{
  name: "Иван Петров",
  email: "i.petrov@rassvet.ru",
  role: "Заказчик",
  company: "ООО «Рассвет»",
  status: "Активен"
}, {
  name: "Мария Сидорова",
  email: "m.sidorova@stroymash.ru",
  role: "Заказчик",
  company: "СК «СтройМаш»",
  status: "Активен"
}, {
  name: "Алексей Козлов",
  email: "a.kozlov@techflow.com",
  role: "Поставщик",
  company: "TechFlow Ltd.",
  status: "Активен"
}, {
  name: "Елена Новикова",
  email: "e.novikova@medprom.ru",
  role: "Поставщик",
  company: "МедПром",
  status: "Заблокирован"
}, {
  name: "Дмитрий Васин",
  email: "d.vasin@admin.ru",
  role: "Модератор",
  company: "—",
  status: "Активен"
}];
function mapBackendUser(u) {
  return {
    name: u.name?.trim() || u.email,
    email: u.email,
    role: "Пользователь",
    company: "—",
    status: "Активен"
  };
}
function Users() {
  const [searchText, setSearchText] = reactExports.useState("");
  const [rows, setRows] = reactExports.useState(users);
  const [loading, setLoading] = reactExports.useState(false);
  const [loadError, setLoadError] = reactExports.useState(null);
  reactExports.useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setLoadError(null);
    fetch(`${getLocalApiBase()}/api/v1/users`).then(async (res) => {
      if (!res.ok) throw new Error(`${res.status}: ${(await res.text()).slice(0, 160)}`);
      return res.json();
    }).then((data) => {
      if (!cancelled && Array.isArray(data) && data.length > 0) setRows(data.map(mapBackendUser));
    }).catch((e) => {
      if (!cancelled) setLoadError(e instanceof Error ? e.message : String(e));
    }).finally(() => {
      if (!cancelled) setLoading(false);
    });
    return () => {
      cancelled = true;
    };
  }, []);
  const visibleUsers = rows.filter((u) => {
    const q = searchText.trim().toLowerCase();
    if (!q) return true;
    return `${u.name} ${u.email} ${u.role} ${u.company} ${u.status}`.toLowerCase().includes(q);
  });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { title: "Пользователи", description: "Учётные записи на платформе" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 p-8", children: [
      loadError && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800", children: [
        "Backend users недоступен, показан локальный список: ",
        loadError
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative max-w-xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: searchText, onChange: (e) => setSearchText(e.target.value), placeholder: "Поиск по пользователю, email, роли, компании...", className: "w-full rounded-lg border border-input bg-background py-2 pl-9 pr-3 text-sm" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-hidden rounded-xl border border-border bg-card", style: {
        boxShadow: "var(--shadow-sm)"
      }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-sm", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3 text-left font-medium", children: "Пользователь" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3 text-left font-medium", children: "Роль" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3 text-left font-medium", children: "Компания" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-6 py-3 text-left font-medium", children: "Статус" })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("tbody", { children: [
          visibleUsers.map((u) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-t border-border hover:bg-muted/40", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-6 py-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-sm font-semibold text-primary", children: u.name.split(" ").map((n) => n[0]).join("") }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-medium text-foreground", children: u.name }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground", children: u.email })
              ] })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-6 py-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "inline-flex rounded-md bg-accent px-2 py-1 text-xs font-medium text-accent-foreground", children: u.role }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-6 py-4 text-muted-foreground", children: u.company }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-6 py-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `inline-flex rounded-full px-2.5 py-1 text-xs font-medium ${u.status === "Активен" ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive"}`, children: u.status }) })
          ] }, u.email)),
          visibleUsers.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("td", { colSpan: 4, className: "px-6 py-16 text-center text-sm text-muted-foreground", children: loading ? "Загрузка пользователей…" : "Пользователи не найдены" }) })
        ] })
      ] }) })
    ] })
  ] });
}
export {
  Users as component
};
