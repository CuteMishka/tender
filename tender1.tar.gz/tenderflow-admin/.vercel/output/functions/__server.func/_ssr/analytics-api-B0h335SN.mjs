import { g as getLocalApiBase } from "./tenders-api-s2Iw9WUl.mjs";
const base = () => getLocalApiBase();
async function get(path, params) {
  const url = new URL(`${base()}${path}`);
  if (params) {
    for (const [k, v] of Object.entries(params)) {
      if (v !== void 0 && v !== "") url.searchParams.set(k, String(v));
    }
  }
  const res = await fetch(url.toString());
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`${res.status}: ${text.slice(0, 200)}`);
  }
  return res.json();
}
async function post(path, body) {
  const res = await fetch(`${base()}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : void 0
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`${res.status}: ${text.slice(0, 200)}`);
  }
  return res.json();
}
async function del(path) {
  const res = await fetch(`${base()}${path}`, { method: "DELETE" });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`${res.status}: ${text.slice(0, 200)}`);
  }
  return res.json();
}
async function put(path, body) {
  const res = await fetch(`${base()}${path}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`${res.status}: ${text.slice(0, 200)}`);
  }
  return res.json();
}
const analyticsApi = {
  sync: () => post("/api/v1/analytics/sync"),
  getLots: (filters = {}) => get("/api/v1/analytics/lots", {
    customer: filters.customer,
    purchase_type: filters.purchase_type,
    region: filters.region,
    winner: filters.winner,
    status: filters.status,
    date_from: filters.date_from,
    date_to: filters.date_to,
    amount_min: filters.amount_min,
    amount_max: filters.amount_max,
    participation: filters.participation,
    excluded: filters.excluded,
    page: filters.page ?? 1,
    limit: filters.limit ?? 20
  }),
  updateLot: (id, data) => put(`/api/v1/analytics/lots/${id}`, data),
  excludeLot: (id) => put(`/api/v1/analytics/lots/${id}`, { excluded_from_analytics: true }),
  restoreLot: (id) => put(`/api/v1/analytics/lots/${id}`, { excluded_from_analytics: false }),
  getStats: () => get("/api/v1/analytics/stats"),
  getDynamics: () => get("/api/v1/analytics/dynamics"),
  getFilters: () => get("/api/v1/analytics/filters"),
  exportCSV: (filters = {}) => {
    const url = new URL(`${base()}/api/v1/analytics/export`);
    const params = {
      customer: filters.customer,
      purchase_type: filters.purchase_type,
      region: filters.region,
      winner: filters.winner,
      status: filters.status,
      date_from: filters.date_from,
      date_to: filters.date_to,
      amount_min: filters.amount_min,
      amount_max: filters.amount_max,
      participation: filters.participation,
      excluded: filters.excluded
    };
    for (const [k, v] of Object.entries(params)) {
      if (v !== void 0 && v !== "") url.searchParams.set(k, String(v));
    }
    window.open(url.toString(), "_blank");
  },
  getCustomers: () => get("/api/v1/analytics/customers"),
  addCustomer: (data) => post("/api/v1/analytics/customers", data),
  updateCustomer: (id, data) => put(`/api/v1/analytics/customers/${id}`, data),
  getCustomerCandidates: (q = "", limit = 80) => get("/api/v1/analytics/customers/candidates", { q, limit }),
  deleteCustomer: (id) => del(`/api/v1/analytics/customers/${id}`),
  getCustomerLots: (id) => get(`/api/v1/analytics/customers/${id}/lots`),
  getWinners: () => get("/api/v1/analytics/winners"),
  getPrices: () => get("/api/v1/analytics/prices")
};
function fmtM(v) {
  if (!v) return "—";
  if (v >= 1e9) return `${(v / 1e9).toFixed(1)} млрд`;
  if (v >= 1e6) return `${(v / 1e6).toFixed(1)} млн`;
  if (v >= 1e3) return `${(v / 1e3).toFixed(0)} тыс`;
  return v.toFixed(0);
}
function fmtN(v) {
  if (!v) return "—";
  return new Intl.NumberFormat("ru-RU").format(v);
}
function fmtDate(s) {
  if (!s) return "—";
  const d = new Date(s);
  if (isNaN(d.getTime())) return "—";
  return d.toLocaleDateString("ru-KZ");
}
function fmtPct(v) {
  if (!v) return "—";
  return `${v.toFixed(1)}%`;
}
export {
  analyticsApi as a,
  fmtDate as b,
  fmtN as c,
  fmtPct as d,
  fmtM as f
};
