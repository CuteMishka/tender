import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { P as PageHeader } from "./PageHeader-BgLmG3Y0.mjs";
import { u as useToast, T as ToastContainer } from "./PageToast-BnKBPqEf.mjs";
import { f as fmtM, b as fmtDate, c as fmtN, a as analyticsApi } from "./analytics-api-B0h335SN.mjs";
import { p as pushNotification } from "./use-notifications-sQ8SQxfy.mjs";
import { p as Plus, X, R as RefreshCw, l as Search, g as Building2, K as Hash, t as DollarSign, N as Calendar, a3 as Mail, a0 as Star, H as History, k as Trash2, V as TriangleAlert } from "../_libs/lucide-react.mjs";
import "./tenders-api-s2Iw9WUl.mjs";
function ConfirmDialog({
  open,
  title,
  description,
  confirmLabel = "Подтвердить",
  cancelLabel = "Отмена",
  danger = false,
  onConfirm,
  onCancel
}) {
  const btnRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    if (open) btnRef.current?.focus();
  }, [open]);
  reactExports.useEffect(() => {
    if (!open) return;
    const handler = (e) => {
      if (e.key === "Escape") onCancel();
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [open, onCancel]);
  if (!open) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      className: "fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-in fade-in-0 duration-150",
      onClick: onCancel,
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: "w-full max-w-sm rounded-xl border border-border bg-card p-6 shadow-2xl animate-in zoom-in-95 duration-150",
          onClick: (e) => e.stopPropagation(),
          children: [
            danger && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-4 flex h-10 w-10 items-center justify-center rounded-full bg-destructive/10", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "h-5 w-5 text-destructive" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-semibold text-foreground", children: title }),
            description && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1.5 text-sm text-muted-foreground", children: description }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-5 flex justify-end gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  onClick: onCancel,
                  className: "rounded-lg border border-border px-4 py-2 text-sm font-medium hover:bg-accent transition-colors",
                  children: cancelLabel
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  ref: btnRef,
                  onClick: onConfirm,
                  className: `rounded-lg px-4 py-2 text-sm font-medium text-white transition-opacity hover:opacity-90 ${danger ? "bg-destructive" : "bg-primary"}`,
                  children: confirmLabel
                }
              )
            ] })
          ]
        }
      )
    }
  );
}
function CustomersAnalytics() {
  const toast = useToast();
  const [customers, setCustomers] = reactExports.useState([]);
  const [loading, setLoading] = reactExports.useState(true);
  const [showAdd, setShowAdd] = reactExports.useState(false);
  const [adding, setAdding] = reactExports.useState(false);
  const [deleteTarget, setDeleteTarget] = reactExports.useState(null);
  const [formName, setFormName] = reactExports.useState("");
  const [formCustomerId, setFormCustomerId] = reactExports.useState("");
  const [formEmail, setFormEmail] = reactExports.useState("");
  const [formNotes, setFormNotes] = reactExports.useState("");
  const [formError, setFormError] = reactExports.useState(null);
  const [candidateQuery, setCandidateQuery] = reactExports.useState("");
  const [candidates, setCandidates] = reactExports.useState([]);
  const [candidatesLoading, setCandidatesLoading] = reactExports.useState(false);
  const [selectedCandidateName, setSelectedCandidateName] = reactExports.useState(null);
  const [candidateLots, setCandidateLots] = reactExports.useState([]);
  const [candidateLotsLoading, setCandidateLotsLoading] = reactExports.useState(false);
  const [selectedId, setSelectedId] = reactExports.useState(null);
  const [customerLots, setCustomerLots] = reactExports.useState(null);
  const [lotsLoading, setLotsLoading] = reactExports.useState(false);
  const load = async () => {
    setLoading(true);
    try {
      setCustomers(await analyticsApi.getCustomers() ?? []);
    } catch (e) {
      toast.error(`Ошибка загрузки: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setLoading(false);
    }
  };
  reactExports.useEffect(() => {
    load();
  }, []);
  const loadCandidates = async (q = candidateQuery) => {
    setCandidatesLoading(true);
    try {
      setCandidates(await analyticsApi.getCustomerCandidates(q, 80) ?? []);
    } catch (e) {
      toast.error(`Ошибка загрузки заказчиков из истории: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setCandidatesLoading(false);
    }
  };
  reactExports.useEffect(() => {
    loadCandidates("");
  }, []);
  const handleAdd = async (e) => {
    e.preventDefault();
    if (!formName.trim()) {
      setFormError("Введите имя заказчика");
      return;
    }
    setAdding(true);
    setFormError(null);
    try {
      await analyticsApi.addCustomer({
        customer_name: formName.trim(),
        customer_id: formCustomerId,
        notify_email: formEmail,
        notes: formNotes
      });
      pushNotification("success", "Заказчик отслеживается", `«${formName.trim()}» добавлен в избранные заказчики.`, "/analytics/customers", "mentions");
      setFormName("");
      setFormCustomerId("");
      setFormEmail("");
      setFormNotes("");
      setShowAdd(false);
      await Promise.all([load(), loadCandidates("")]);
    } catch (e2) {
      setFormError(e2 instanceof Error ? e2.message : String(e2));
    } finally {
      setAdding(false);
    }
  };
  const handleDeleteConfirm = async () => {
    if (!deleteTarget) return;
    try {
      await analyticsApi.deleteCustomer(deleteTarget.id);
      setCustomers((prev) => prev.filter((c) => c.id !== deleteTarget.id));
      if (selectedId === deleteTarget.id) {
        setSelectedId(null);
        setCustomerLots(null);
      }
      toast.success(`«${deleteTarget.customer_name}» удалён из отслеживаемых`);
    } catch (e) {
      toast.error(`Ошибка удаления: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setDeleteTarget(null);
    }
  };
  const addCandidate = async (candidate) => {
    setAdding(true);
    try {
      await analyticsApi.addCustomer({
        customer_name: candidate.customer_name,
        customer_id: candidate.customer_id,
        notes: `Добавлен из истории закупок: ${candidate.tender_count} тендер(ов)`
      });
      pushNotification("success", "Заказчик добавлен", `«${candidate.customer_name}» добавлен в избранные.`, "/analytics/customers", "mentions");
      await Promise.all([load(), loadCandidates(candidateQuery)]);
    } catch (e) {
      toast.error(`Не удалось добавить: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setAdding(false);
    }
  };
  const toggleFavorite = async (customer) => {
    try {
      const updated = await analyticsApi.updateCustomer(customer.id, {
        customer_name: customer.customer_name,
        customer_id: customer.customer_id,
        notify_email: customer.notify_email,
        notes: customer.notes,
        is_favorite: !customer.is_favorite
      });
      setCustomers((prev) => prev.map((c) => c.id === customer.id ? {
        ...c,
        is_favorite: updated.is_favorite
      } : c));
    } catch (e) {
      toast.error(`Не удалось обновить избранное: ${e instanceof Error ? e.message : String(e)}`);
    }
  };
  const handleCandidateHistory = async (name) => {
    if (selectedCandidateName === name) {
      setSelectedCandidateName(null);
      setCandidateLots([]);
      return;
    }
    setSelectedCandidateName(name);
    setCandidateLotsLoading(true);
    try {
      const res = await analyticsApi.getLots({
        customer: name,
        limit: 10
      });
      setCandidateLots(res.items ?? []);
    } catch (e) {
      toast.error(`Не удалось загрузить прошлые заказы: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setCandidateLotsLoading(false);
    }
  };
  const handleSelect = async (id) => {
    if (selectedId === id) {
      setSelectedId(null);
      setCustomerLots(null);
      return;
    }
    setSelectedId(id);
    setLotsLoading(true);
    try {
      const cl = await analyticsApi.getCustomerLots(id);
      setCustomerLots({
        customer: cl.customer,
        lots: cl.lots ?? []
      });
    } catch (e) {
      console.error(e);
    } finally {
      setLotsLoading(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { title: "Трекинг заказчиков", description: "Мониторинг закупочной активности заказчиков", actions: /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => setShowAdd((v) => !v), className: "inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4" }),
      " Добавить заказчика"
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6 p-8", children: [
      showAdd && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card p-6 animate-in slide-in-from-top-2", style: {
        boxShadow: "var(--shadow-sm)"
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold", children: "Новый заказчик" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setShowAdd(false), className: "text-muted-foreground hover:text-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4" }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleAdd, className: "grid gap-3 sm:grid-cols-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "sm:col-span-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "mb-1 block text-xs font-medium text-muted-foreground", children: "Наименование заказчика *" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: formName, onChange: (e) => setFormName(e.target.value), required: true, placeholder: "Например: АО «Казтелеком»", className: "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "mb-1 block text-xs font-medium text-muted-foreground", children: "БИН / ИИН" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: formCustomerId, onChange: (e) => setFormCustomerId(e.target.value), placeholder: "123456789012", className: "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "mb-1 block text-xs font-medium text-muted-foreground", children: "Email для уведомлений" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "email", value: formEmail, onChange: (e) => setFormEmail(e.target.value), placeholder: "email@company.kz", className: "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "mb-1 block text-xs font-medium text-muted-foreground", children: "Заметки" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: formNotes, onChange: (e) => setFormNotes(e.target.value), placeholder: "Приоритетный заказчик и т.д.", className: "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm" })
          ] }),
          formError && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "sm:col-span-2 text-sm text-destructive", children: formError }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "sm:col-span-2 flex gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "submit", disabled: adding, className: "rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-50", children: adding ? "Сохранение…" : "Добавить" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setShowAdd(false), className: "rounded-lg border border-border bg-background px-4 py-2 text-sm font-medium hover:bg-accent", children: "Отмена" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card p-6", style: {
        boxShadow: "var(--shadow-sm)"
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex flex-wrap items-center justify-between gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold", children: "Выбрать заказчика из истории" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "Список формируется из исторических закупок после синхронизации." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => loadCandidates(candidateQuery), className: "inline-flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2 text-sm hover:bg-accent", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: `h-4 w-4 ${candidatesLoading ? "animate-spin" : ""}` }),
            " Обновить"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-3 flex gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative min-w-0 flex-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: candidateQuery, onChange: (e) => setCandidateQuery(e.target.value), onKeyDown: (e) => {
              if (e.key === "Enter") loadCandidates(candidateQuery);
            }, placeholder: "Поиск по названию заказчика", className: "w-full rounded-lg border border-input bg-background py-2 pl-9 pr-3 text-sm" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => loadCandidates(candidateQuery), className: "rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90", children: "Найти" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-2 md:grid-cols-2 xl:grid-cols-3", children: [
          candidates.slice(0, 12).map((c) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-lg border border-border bg-background p-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "truncate text-sm font-medium", children: c.customer_name }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-0.5 text-xs text-muted-foreground", children: [
                  c.tender_count,
                  " тенд. · ₸ ",
                  fmtM(c.total_budget)
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex shrink-0 gap-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => handleCandidateHistory(c.customer_name), className: `rounded-lg border px-2 py-1 text-xs font-medium ${selectedCandidateName === c.customer_name ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:bg-accent"}`, children: "История" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("button", { disabled: adding || c.is_tracked, onClick: () => addCandidate(c), className: `rounded-lg px-2 py-1 text-xs font-medium ${c.is_tracked ? "bg-green-100 text-green-700" : "bg-primary text-primary-foreground hover:opacity-90"}`, children: c.is_tracked ? "Добавлен" : "В избранные" })
              ] })
            ] }),
            selectedCandidateName === c.customer_name && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-3 border-t border-border pt-3", children: candidateLotsLoading ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "Загрузка прошлых заказов…" }) : candidateLots.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: candidateLots.slice(0, 5).map((lot) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-md bg-muted/40 px-2 py-1.5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "truncate text-xs font-medium", children: lot.title }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-0.5 text-[11px] text-muted-foreground", children: [
                lot.purchase_type || "Вид закупки не указан",
                " · ₸ ",
                fmtM(lot.initial_amount),
                " · ",
                fmtDate(lot.end_date)
              ] })
            ] }, lot.id)) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "Прошлые заказы не найдены." }) })
          ] }, `${c.customer_name}-${c.customer_id}`)),
          !candidatesLoading && candidates.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Нет кандидатов. Сначала синхронизируйте историю тендеров." })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "overflow-hidden rounded-xl border border-border bg-card", style: {
        boxShadow: "var(--shadow-sm)"
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border-b border-border px-6 py-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold", children: "Отслеживаемые заказчики" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-muted-foreground", children: [
            customers.length,
            " заказчик(ов)"
          ] })
        ] }),
        loading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-center py-12 text-sm text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mr-2 h-5 w-5 animate-spin rounded-full border-2 border-muted border-t-primary" }),
          " Загрузка…"
        ] }) : customers.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center justify-center py-16 text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className: "mb-3 h-10 w-10 opacity-20" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium", children: "Нет отслеживаемых заказчиков" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs", children: "Нажмите «Добавить заказчика» для начала мониторинга" })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "divide-y divide-border", children: [...customers].sort((a, b) => (b.is_favorite ? 1 : 0) - (a.is_favorite ? 1 : 0)).map((c) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex items-center gap-4 px-6 py-4 transition hover:bg-muted/30 ${selectedId === c.id ? "bg-muted/40" : ""} ${c.is_favorite ? "border-l-2 border-l-yellow-400 pl-5" : ""}`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `flex h-10 w-10 shrink-0 items-center justify-center rounded-full font-semibold text-sm ${c.is_favorite ? "bg-yellow-100 text-yellow-700" : "bg-primary/10 text-primary"}`, children: c.customer_name[0]?.toUpperCase() ?? "?" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium text-foreground truncate", children: c.customer_name }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-0.5 flex flex-wrap gap-3 text-xs text-muted-foreground", children: [
                c.tender_count > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Hash, { className: "h-3 w-3" }),
                  c.tender_count,
                  " тенд."
                ] }),
                c.total_budget > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(DollarSign, { className: "h-3 w-3" }),
                  "₸ ",
                  fmtM(c.total_budget)
                ] }),
                c.last_tender_at && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "h-3 w-3" }),
                  "посл. ",
                  fmtDate(c.last_tender_at)
                ] }),
                c.notify_email && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, { className: "h-3 w-3" }),
                  c.notify_email
                ] })
              ] }),
              c.notes && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-0.5 text-xs text-muted-foreground/70 truncate", children: c.notes })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex shrink-0 items-center gap-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => toggleFavorite(c), title: c.is_favorite ? "Убрать из избранного" : "Добавить в избранное", className: `rounded-lg p-1.5 transition ${c.is_favorite ? "text-yellow-500 hover:bg-yellow-100" : "text-muted-foreground hover:bg-accent"}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Star, { className: `h-4 w-4 ${c.is_favorite ? "fill-current" : ""}` }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => handleSelect(c.id), className: `inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition ${selectedId === c.id ? "border-primary bg-primary/10 text-primary" : "border-border bg-background text-muted-foreground hover:bg-accent"}`, children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(History, { className: "h-3.5 w-3.5" }),
                " История"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setDeleteTarget(c), className: "rounded-lg p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) })
            ] })
          ] }),
          selectedId === c.id && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "border-t border-border bg-muted/20 px-6 py-4", children: lotsLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-sm text-muted-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-4 w-4 animate-spin rounded-full border-2 border-muted border-t-primary" }),
            " Загрузка истории…"
          ] }) : customerLots && customerLots.lots.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "overflow-x-auto", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: [
              "История закупок — ",
              customerLots.lots.length,
              " тендер(ов)"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full min-w-[700px] text-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "text-left text-muted-foreground", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "pb-2 font-medium", children: "ID" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "pb-2 font-medium", children: "Наименование" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "pb-2 font-medium", children: "Вид закупки" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "pb-2 text-right font-medium", children: "Нач. цена" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "pb-2 font-medium", children: "Дата" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "pb-2 font-medium", children: "Победитель" })
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { className: "divide-y divide-border", children: customerLots.lots.slice(0, 20).map((lot) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "hover:bg-muted/30", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2 font-mono text-muted-foreground", children: lot.lot_id }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2 max-w-[280px] truncate font-medium", children: lot.title }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2 text-muted-foreground", children: lot.purchase_type || "—" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2 text-right tabular-nums font-semibold", children: fmtN(lot.initial_amount) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2 text-muted-foreground", children: fmtDate(lot.end_date) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "py-2 text-muted-foreground truncate max-w-[120px]", children: lot.winner_name || "—" })
              ] }, lot.id)) })
            ] }),
            customerLots.lots.length > 20 && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-2 text-xs text-muted-foreground", children: [
              "… и ещё ",
              customerLots.lots.length - 20,
              " тендер(ов)"
            ] })
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Нет данных. Синхронизируйте тендеры на странице «История тендеров»." }) })
        ] }, c.id)) })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(ConfirmDialog, { open: deleteTarget !== null, title: "Удалить заказчика?", description: deleteTarget ? `«${deleteTarget.customer_name}» будет удалён из списка отслеживаемых.` : void 0, confirmLabel: "Удалить", danger: true, onConfirm: handleDeleteConfirm, onCancel: () => setDeleteTarget(null) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(ToastContainer, { toasts: toast.toasts, onDismiss: toast.dismiss })
  ] });
}
export {
  CustomersAnalytics as component
};
