const __vite_import_meta_env__ = {};
const VIEWED_KEY = "viewed_tenders";
const VIEWED_INFO_KEY = "viewed_tenders_info";
function getCurrentViewer() {
  try {
    return localStorage.getItem("tender_viewer_name") || "Администратор";
  } catch {
    return "Администратор";
  }
}
function loadViewInfoMap() {
  try {
    const raw = localStorage.getItem(VIEWED_INFO_KEY);
    if (!raw) return {};
    return JSON.parse(raw);
  } catch {
    return {};
  }
}
function saveViewInfoMap(map) {
  try {
    const keys = Object.keys(map);
    if (keys.length > 500) {
      const trimmed = {};
      for (const k of keys.slice(-500)) trimmed[k] = map[k];
      localStorage.setItem(VIEWED_INFO_KEY, JSON.stringify(trimmed));
    } else {
      localStorage.setItem(VIEWED_INFO_KEY, JSON.stringify(map));
    }
  } catch {
  }
}
function markTenderViewed(id) {
  try {
    const set = getViewedTenders();
    set.add(id);
    const arr = [...set].slice(-500);
    localStorage.setItem(VIEWED_KEY, JSON.stringify(arr));
    const map = loadViewInfoMap();
    if (!map[String(id)]) {
      map[String(id)] = {
        viewer: getCurrentViewer(),
        viewedAt: (/* @__PURE__ */ new Date()).toISOString(),
        decision: null,
        decisionAt: null
      };
      saveViewInfoMap(map);
    }
  } catch {
  }
}
function markTenderDecision(id, decision) {
  try {
    const map = loadViewInfoMap();
    const existing = map[String(id)] || {
      viewer: getCurrentViewer(),
      viewedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    map[String(id)] = {
      ...existing,
      decision,
      decisionAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    saveViewInfoMap(map);
  } catch {
  }
}
function getTenderViewInfo(id) {
  try {
    const map = loadViewInfoMap();
    return map[String(id)] || null;
  } catch {
    return null;
  }
}
function getAllViewInfo() {
  return loadViewInfoMap();
}
function getViewedTenders() {
  try {
    const raw = localStorage.getItem(VIEWED_KEY);
    if (!raw) return /* @__PURE__ */ new Set();
    return new Set(JSON.parse(raw));
  } catch {
    return /* @__PURE__ */ new Set();
  }
}
const SPEC_KEY = "tender_spec_cache";
function saveTenderSpecCache(tenderId, data) {
  try {
    const raw = localStorage.getItem(SPEC_KEY);
    const map = raw ? JSON.parse(raw) : {};
    map[String(tenderId)] = { ...data, savedAt: (/* @__PURE__ */ new Date()).toISOString() };
    const keys = Object.keys(map);
    if (keys.length > 200) {
      const trimmed = {};
      for (const k of keys.slice(-200)) trimmed[k] = map[k];
      localStorage.setItem(SPEC_KEY, JSON.stringify(trimmed));
    } else {
      localStorage.setItem(SPEC_KEY, JSON.stringify(map));
    }
  } catch {
  }
}
function getTenderSpecCache(tenderId) {
  try {
    const raw = localStorage.getItem(SPEC_KEY);
    if (!raw) return null;
    const map = JSON.parse(raw);
    return map[String(tenderId)] || null;
  } catch {
    return null;
  }
}
function getTenderStatus(endDate) {
  if (!endDate) return { label: "Неизвестно", color: "gray", daysLeft: null };
  const end = new Date(endDate);
  if (isNaN(end.getTime())) return { label: "Неизвестно", color: "gray", daysLeft: null };
  const now = /* @__PURE__ */ new Date();
  const diffMs = end.getTime() - now.getTime();
  const daysLeft = Math.ceil(diffMs / (1e3 * 60 * 60 * 24));
  if (daysLeft < 0) return { label: "Завершён", color: "gray", daysLeft };
  if (daysLeft <= 3) return { label: `${daysLeft} дн.`, color: "red", daysLeft };
  if (daysLeft <= 14) return { label: `${daysLeft} дн.`, color: "orange", daysLeft };
  return { label: `${daysLeft} дн.`, color: "green", daysLeft };
}
function tenderCompanyName(tender) {
  return (tender.customer_name || tender.customerName || tender.organizer_name || tender.organizerName || tender.partner || "").trim();
}
const DEFAULT_API_BASE = "https://tenderai-production-70a1.up.railway.app";
function getTenderApiBase() {
  const fromEnv = typeof import.meta !== "undefined" && "http://localhost:8082" || typeof process !== "undefined" && process.env?.VITE_BACK_API;
  const base = typeof fromEnv === "string" && fromEnv.trim() || DEFAULT_API_BASE;
  return base.replace(/\/$/, "");
}
function getLocalApiBase() {
  if (typeof import.meta !== "undefined" && __vite_import_meta_env__) {
    const back = "http://localhost:8082";
    if (back.trim()) return back.trim().replace(/\/$/, "");
  }
  return "http://localhost:8082";
}
function normalizeInput(input) {
  const page = Number.isFinite(input.page) && input.page >= 1 ? Math.floor(input.page) : 1;
  const limit = typeof input.limit === "number" && Number.isFinite(input.limit) && input.limit >= 1 && input.limit <= 50 ? Math.floor(input.limit) : 10;
  return { page, limit };
}
function normalizeDocuments(raw) {
  if (!Array.isArray(raw)) return void 0;
  const out = [];
  for (const entry of raw) {
    if (!entry || typeof entry !== "object") continue;
    const e = entry;
    if (typeof e.name === "string" && typeof e.downloadLink === "string") {
      out.push({ name: e.name, downloadLink: e.downloadLink });
    }
  }
  return out;
}
function readTechnicalSpecification(o) {
  const keys = [
    "technical_specification",
    "technicalSpecification",
    "specification",
    "tech_specification",
    "techSpecification"
  ];
  for (const k of keys) {
    const v = o[k];
    if (typeof v === "string" && v.trim()) return v;
  }
  return void 0;
}
function readAiAnalysis(o) {
  const keys = [
    "ai_analysis",
    "aiAnalysis",
    "llm_analysis",
    "llmAnalysis",
    "ai_summary",
    "aiSummary"
  ];
  for (const k of keys) {
    const v = o[k];
    if (typeof v === "string" && v.trim()) return v;
  }
  return void 0;
}
function normalizeTenderPayload(body) {
  if (!body || typeof body !== "object") return null;
  const o = body;
  if (typeof o.id === "number" && typeof o.title === "string") {
    const documents = normalizeDocuments(o.documents);
    const technical_specification = readTechnicalSpecification(o);
    const ai_analysis = readAiAnalysis(o);
    return {
      ...o,
      documents,
      purchaseType: typeof o.purchaseType === "string" ? o.purchaseType : null,
      endDate: typeof o.endDate === "string" ? o.endDate : null,
      startDate: typeof o.startDate === "string" ? o.startDate : null,
      region: typeof o.region === "string" ? o.region : null,
      partner: typeof o.partner === "string" ? o.partner : null,
      organizer_name: typeof o.organizer_name === "string" ? o.organizer_name : null,
      organizerName: typeof o.organizerName === "string" ? o.organizerName : null,
      customer_name: typeof o.customer_name === "string" ? o.customer_name : null,
      customerName: typeof o.customerName === "string" ? o.customerName : null,
      status: typeof o.status === "string" ? o.status : null,
      ...technical_specification !== void 0 ? { technical_specification } : {},
      ...ai_analysis !== void 0 ? { ai_analysis } : {}
    };
  }
  for (const key of ["item", "data", "tender"]) {
    const nested = o[key];
    if (nested && typeof nested === "object") {
      const found = normalizeTenderPayload(nested);
      if (found) return found;
    }
  }
  return null;
}
function getItemsArrayFromListBody(raw) {
  if (Array.isArray(raw)) return raw;
  if (!raw || typeof raw !== "object") return [];
  const o = raw;
  for (const key of ["items", "data", "results", "tenders", "list"]) {
    const v = o[key];
    if (Array.isArray(v)) return v;
  }
  if (o.data && typeof o.data === "object" && !Array.isArray(o.data)) {
    const d = o.data;
    if (Array.isArray(d.items)) return d.items;
    if (Array.isArray(d.data)) return d.data;
  }
  return [];
}
function defaultListMeta(items, limit) {
  return {
    firstId: items[0]?.id ?? 0,
    lastId: items[items.length - 1]?.id ?? 0,
    limitPage: limit,
    pageCount: 1,
    totalCount: items.length
  };
}
function metaFromRecord(m, items, limit) {
  return {
    firstId: typeof m.firstId === "number" ? m.firstId : items[0]?.id ?? 0,
    lastId: typeof m.lastId === "number" ? m.lastId : items[items.length - 1]?.id ?? 0,
    limitPage: typeof m.limitPage === "number" ? m.limitPage : limit,
    pageCount: typeof m.pageCount === "number" ? Math.max(1, m.pageCount) : 1,
    totalCount: typeof m.totalCount === "number" ? m.totalCount : items.length
  };
}
function readListMetaFromEnvelope(raw, items, limit) {
  if (!raw || typeof raw !== "object") return defaultListMeta(items, limit);
  const o = raw;
  let block = o.meta ?? (o.extensions && typeof o.extensions === "object" && !Array.isArray(o.extensions) ? o.extensions : void 0);
  if (!block && o.data && typeof o.data === "object" && !Array.isArray(o.data)) {
    const d = o.data;
    block = d.meta ?? (d.extensions && typeof d.extensions === "object" && !Array.isArray(d.extensions) ? d.extensions : void 0);
  }
  if (block && typeof block === "object") {
    return metaFromRecord(block, items, limit);
  }
  return defaultListMeta(items, limit);
}
function normalizeTendersListResponse(raw, limit) {
  const arr = getItemsArrayFromListBody(raw);
  const items = [];
  for (const entry of arr) {
    const t = normalizeTenderPayload(entry);
    if (t) items.push(t);
  }
  const meta = readListMetaFromEnvelope(raw, items, limit);
  return { items, meta };
}
async function fetchTendersList(input) {
  const { page, limit } = normalizeInput(input);
  const base = getTenderApiBase();
  const params = new URLSearchParams();
  params.set("limit", String(limit));
  params.set("page", String(page));
  if (input.keywords?.trim()) params.set("keywords", input.keywords.trim());
  const url = `${base}/api/v1/tenders?${params.toString()}`;
  const res = await fetch(url);
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Tenders API ${res.status}: ${text.slice(0, 240)}`);
  }
  let raw;
  try {
    raw = await res.json();
  } catch {
    raw = null;
  }
  return normalizeTendersListResponse(raw, limit);
}
async function fetchTenderById(id) {
  if (!Number.isFinite(id) || id < 1) {
    throw new Error("Некорректный ID тендера");
  }
  const base = getTenderApiBase();
  const detailRes = await fetch(`${base}/api/v1/tenders/${id}`);
  if (detailRes.ok) {
    let body;
    try {
      body = await detailRes.json();
    } catch {
      body = null;
    }
    const fromDetail = normalizeTenderPayload(body);
    if (fromDetail) return fromDetail;
  } else if (detailRes.status !== 404 && detailRes.status !== 405) {
    const text = await detailRes.text();
    throw new Error(`Tenders API ${detailRes.status}: ${text.slice(0, 240)}`);
  }
  const maxPages = 50;
  for (let page = 1; page <= maxPages; page++) {
    const list = await fetchTendersList({ page, limit: 50 });
    const hit = list.items.find((t) => t.id === id);
    if (hit) return hit;
    if (page >= (list.meta.pageCount || 1)) break;
  }
  throw new Error("Тендер не найден");
}
function sanitizeApiText(s) {
  if (!s) return "";
  let t = s.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  t = t.replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number.parseInt(n, 10)));
  t = t.replace(
    /&#x([0-9a-fA-F]+);/g,
    (_, h) => String.fromCodePoint(Number.parseInt(h, 16))
  );
  return t.replace(/\s+/g, " ").trim();
}
function sanitizeApiTextMultiline(s) {
  if (!s) return "";
  let t = s.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  t = t.replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number.parseInt(n, 10)));
  t = t.replace(
    /&#x([0-9a-fA-F]+);/g,
    (_, h) => String.fromCodePoint(Number.parseInt(h, 16))
  );
  return t.trim();
}
function formatTenderAmount(cost) {
  if (!Number.isFinite(cost) || cost < 0) return "—";
  if (cost === 0) return "0";
  return new Intl.NumberFormat("ru-RU", {
    maximumFractionDigits: 2,
    minimumFractionDigits: 0
  }).format(cost);
}
function formatDate(dateStr) {
  if (!dateStr) return "—";
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return "—";
  return d.toLocaleString("ru-KZ", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  });
}
const DEFAULT_LOT_ANALYZE_BASE = "http://127.0.0.1:8083";
function readRagServiceBaseFromEnv() {
  if (typeof import.meta !== "undefined" && __vite_import_meta_env__) {
    const rag = "http://localhost:8083";
    if (rag.trim()) return rag.trim();
  }
  if (typeof process !== "undefined" && process.env) {
    const rag = process.env.VITE_RAG_API;
    if (typeof rag === "string" && rag.trim()) return rag.trim();
    const legacy = process.env.VITE_LOT_ANALYZE_API;
    if (typeof legacy === "string" && legacy.trim()) return legacy.trim();
  }
  return void 0;
}
function getRagApiBase() {
  const base = readRagServiceBaseFromEnv() || DEFAULT_LOT_ANALYZE_BASE;
  return base.replace(/\/$/, "");
}
function buildLotText(t) {
  const main = sanitizeApiText(t.description) || sanitizeApiText(t.title) || sanitizeApiText(t.lot);
  const place = sanitizeApiText(t.place);
  const sumPart = Number.isFinite(t.cost) && t.cost >= 0 ? `сумма ${formatTenderAmount(t.cost)} тг` : "";
  const suffix = [place || null, sumPart || null].filter(Boolean).join(", ");
  if (!suffix) return main || "—";
  const sep = main.endsWith(".") ? " " : ". ";
  return `${main}${sep}${suffix}.`;
}
const LOT_ANALYZE_CACHE_PREFIX = "lot_analyze_cache_v1:";
const LOT_ANALYZE_ATTEMPT_PREFIX = "lot_analyze_attempt_v1:";
const LOT_ANALYZE_CACHE_TTL_MS = 24 * 60 * 60 * 1e3;
const lotAnalyzeInFlight = /* @__PURE__ */ new Map();
const DEFAULT_COMPANY_PROFILE = "Компания оказывает услуги по облачной инфраструктуре IaaS, серверному оборудованию, виртуализации, резервному копированию, технической поддержке и внедрению IT-инфраструктуры.";
function readCompanyProfile() {
  if (typeof process !== "undefined" && process.env?.VITE_COMPANY_PROFILE) {
    const profile = process.env.VITE_COMPANY_PROFILE;
    if (typeof profile === "string" && profile.trim()) return profile.trim();
  }
  return DEFAULT_COMPANY_PROFILE;
}
function stableHash(input) {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(36);
}
function normalizeLotAnalyzeResult(raw) {
  if (typeof raw === "string") {
    const text = raw.trim();
    if (!text) return null;
    try {
      return normalizeLotAnalyzeResult(JSON.parse(text));
    } catch {
      return { summary: text, fit: "сомнительно", score: 50, reason: text, checks: null, raw: text };
    }
  }
  if (!raw || typeof raw !== "object") return null;
  const o = raw;
  const scoreValue = Number(o.score);
  const score = Number.isFinite(scoreValue) ? Math.max(0, Math.min(100, Math.round(scoreValue))) : 50;
  const summary = typeof o.summary === "string" && o.summary.trim() ? o.summary.trim() : "";
  const fit = typeof o.fit === "string" && o.fit.trim() ? o.fit.trim() : "сомнительно";
  const reason = typeof o.reason === "string" && o.reason.trim() ? o.reason.trim() : "";
  const checks = typeof o.checks === "string" && o.checks.trim() ? o.checks.trim() : null;
  if (!summary && !reason) return null;
  return { summary: summary || reason, fit, score, reason: reason || summary, checks };
}
function removeLotAnalyzeAttemptKeys() {
  try {
    for (let i = localStorage.length - 1; i >= 0; i--) {
      const key = localStorage.key(i);
      if (key?.startsWith(LOT_ANALYZE_ATTEMPT_PREFIX)) localStorage.removeItem(key);
    }
  } catch {
  }
}
function readLotAnalyzeCache(cacheKey) {
  try {
    const raw = localStorage.getItem(LOT_ANALYZE_CACHE_PREFIX + cacheKey);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed.ts) return null;
    if (Date.now() - parsed.ts > LOT_ANALYZE_CACHE_TTL_MS) {
      localStorage.removeItem(LOT_ANALYZE_CACHE_PREFIX + cacheKey);
      return null;
    }
    return normalizeLotAnalyzeResult(parsed.value);
  } catch {
    return null;
  }
}
function writeLotAnalyzeCache(cacheKey, value) {
  try {
    localStorage.setItem(LOT_ANALYZE_CACHE_PREFIX + cacheKey, JSON.stringify({ ts: Date.now(), value }));
  } catch {
  }
}
async function fetchLotAnalyze(lotText, options) {
  const trimmed = lotText.trim();
  if (!trimmed) return null;
  removeLotAnalyzeAttemptKeys();
  const cacheKey = options?.cacheKey || stableHash(trimmed);
  if (!options?.force) {
    const cached = readLotAnalyzeCache(cacheKey);
    if (cached) return cached;
    const pending = lotAnalyzeInFlight.get(cacheKey);
    if (pending) return pending;
  }
  const request = (async () => {
    const base = getRagApiBase();
    const url = `${base}/v1/lot/analyze`;
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json, text/plain;q=0.9, */*;q=0.8" },
      body: JSON.stringify({ lot_text: trimmed, profile: readCompanyProfile() })
    });
    const rawText = await res.text();
    if (!res.ok) {
      throw new Error(`Анализ лота ${res.status}: ${rawText.slice(0, 240)}`);
    }
    const t = rawText.trim();
    if (!t) return null;
    try {
      const parsed = JSON.parse(t);
      const result = normalizeLotAnalyzeResult(parsed);
      if (result) {
        writeLotAnalyzeCache(cacheKey, result);
        return result;
      }
    } catch {
    }
    const fallback = normalizeLotAnalyzeResult(t);
    if (fallback) writeLotAnalyzeCache(cacheKey, fallback);
    return fallback;
  })();
  if (!options?.force) lotAnalyzeInFlight.set(cacheKey, request);
  try {
    return await request;
  } finally {
    lotAnalyzeInFlight.delete(cacheKey);
  }
}
function getFetchDocumentProxyUrl() {
  if (typeof import.meta !== "undefined" && "http://localhost:8082") {
    const u = String("http://localhost:8082").trim();
    if (u) return u;
  }
  if (typeof process !== "undefined" && process.env?.VITE_FETCH_DOCUMENT_PROXY_URL) {
    const u = String(process.env.VITE_FETCH_DOCUMENT_PROXY_URL).trim();
    if (u) return u;
  }
  return `${getLocalApiBase()}/api/v1/fetch-document`;
}
function readFetchDocumentProxyError(status, rawText) {
  try {
    const j = JSON.parse(rawText);
    if (j && typeof j === "object" && "detail" in j) {
      const d = j.detail;
      if (typeof d === "string" && d.trim()) return d.trim();
    }
  } catch {
  }
  const t = rawText.trim();
  return t ? t.slice(0, 400) : `HTTP ${status}`;
}
async function fetchDocumentBlobViaBackendProxy(remoteUrl) {
  const proxy = getFetchDocumentProxyUrl();
  const res = await fetch(proxy, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/octet-stream, application/pdf, application/msword, */*"
    },
    body: JSON.stringify({ url: remoteUrl })
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    const detail = readFetchDocumentProxyError(res.status, text);
    throw new Error(`Прокси документа (${res.status}): ${detail}`);
  }
  return res.blob();
}
function guessRagDocExtension(name, downloadLink) {
  const tryOne = (s) => {
    const m = s.match(/\.(pdf|docx|doc)(?:[\s?#]|$)/i);
    return m ? m[1].toLowerCase() : null;
  };
  return tryOne(name) ?? tryOne(downloadLink);
}
function pickTenderDocumentForRag(documents) {
  if (!documents?.length) return null;
  const ok = documents.filter((d) => guessRagDocExtension(d.name, d.downloadLink) !== null);
  if (!ok.length) return null;
  const kw = /спецификац|технич|т\.?\s*з\.?|техзадан/i;
  const preferred = ok.find((d) => kw.test(d.name));
  return preferred ?? ok[0];
}
function tenderDocumentBlobToFile(doc, blob) {
  const ext = guessRagDocExtension(doc.name, doc.downloadLink);
  let fname = doc.name.trim();
  if (!fname) fname = ext ? `document.${ext}` : "document.bin";
  const mime = blob.type && blob.type !== "application/octet-stream" ? blob.type : ext === "pdf" ? "application/pdf" : ext === "docx" ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document" : ext === "doc" ? "application/msword" : "application/octet-stream";
  return new File([blob], fname, { type: mime });
}
function parseIndexDocumentJson(body) {
  if (!body || typeof body !== "object") {
    return { indexed: false };
  }
  const o = body;
  const spec = o.spec_summary;
  return {
    indexed: o.indexed === true,
    text_chars: typeof o.text_chars === "number" ? o.text_chars : void 0,
    extracted_text: typeof o.extracted_text === "string" ? o.extracted_text : void 0,
    spec_summary: spec && typeof spec === "object" && !Array.isArray(spec) ? spec : void 0
  };
}
function formatRagIndexError(status, rawText, body) {
  const detail = body && typeof body === "object" && "detail" in body ? String(body.detail) : rawText.trim().slice(0, 400);
  if (status === 503) return "Выжимка через OpenAI недоступна: не задан OPENAI_API_KEY (503).";
  if (status === 502) return `Ошибка OpenAI при выжимке (502): ${detail || "без деталей"}`;
  if (status === 400) return `Не удалось обработать файл (400): ${detail || "пустой файл или формат"}`;
  return `Индексация документа ${status}: ${detail || rawText.slice(0, 240)}`;
}
async function indexLotDocument(lotId, file, options) {
  const trimmedId = lotId.trim();
  if (!trimmedId) throw new Error("Пустой идентификатор лота");
  const base = getRagApiBase();
  const url = `${base}/v1/lots/${encodeURIComponent(trimmedId)}/index-document`;
  const form = new FormData();
  form.append("file", file);
  if (options?.sourceHint !== void 0 && options.sourceHint !== "") {
    form.append("source_hint", options.sourceHint);
  }
  form.append("extract_spec_points", options?.extractSpecPoints === true ? "true" : "false");
  form.append("include_extracted_text", options?.includeExtractedText === false ? "false" : "true");
  const res = await fetch(url, { method: "POST", body: form });
  const rawText = await res.text();
  let body = null;
  try {
    body = rawText ? JSON.parse(rawText) : null;
  } catch {
    body = null;
  }
  if (!res.ok) {
    throw new Error(formatRagIndexError(res.status, rawText, body));
  }
  return parseIndexDocumentJson(body);
}
async function fetchLotSpecSummary(lotId) {
  const trimmedId = lotId.trim();
  if (!trimmedId) return null;
  const base = getRagApiBase();
  const url = `${base}/v1/lots/${encodeURIComponent(trimmedId)}/spec-summary`;
  const res = await fetch(url);
  const rawText = await res.text();
  if (res.status === 404) return null;
  if (!res.ok) {
    throw new Error(`Выжимка ТЗ ${res.status}: ${rawText.slice(0, 240)}`);
  }
  try {
    const body = rawText ? JSON.parse(rawText) : null;
    if (body && typeof body === "object" && !Array.isArray(body)) {
      return body;
    }
  } catch {
  }
  return null;
}
export {
  getViewedTenders as a,
  getAllViewInfo as b,
  fetchTendersList as c,
  getTenderStatus as d,
  formatDate as e,
  formatTenderAmount as f,
  getLocalApiBase as g,
  getFetchDocumentProxyUrl as h,
  fetchTenderById as i,
  getTenderViewInfo as j,
  getTenderSpecCache as k,
  indexLotDocument as l,
  markTenderViewed as m,
  fetchLotSpecSummary as n,
  saveTenderSpecCache as o,
  pickTenderDocumentForRag as p,
  fetchDocumentBlobViaBackendProxy as q,
  tenderDocumentBlobToFile as r,
  sanitizeApiText as s,
  tenderCompanyName as t,
  fetchLotAnalyze as u,
  sanitizeApiTextMultiline as v,
  buildLotText as w,
  markTenderDecision as x
};
