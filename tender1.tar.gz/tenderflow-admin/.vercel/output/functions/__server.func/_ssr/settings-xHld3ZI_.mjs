import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { P as PageHeader } from "./PageHeader-BgLmG3Y0.mjs";
import { p as pushNotification } from "./use-notifications-sQ8SQxfy.mjs";
const settingsKey = "tender_admin_settings_v1";
const notificationLabels = ["Новые тендеры", "Поступление заявок", "Регистрация компаний", "Системные оповещения"];
const defaultSettings = {
  name: "Администратор",
  email: "admin@tender.ru",
  notifications: Object.fromEntries(notificationLabels.map((label, i) => [label, i < 3]))
};
function loadSettings() {
  try {
    const raw = localStorage.getItem(settingsKey);
    if (!raw) return defaultSettings;
    const parsed = JSON.parse(raw);
    return {
      name: typeof parsed.name === "string" ? parsed.name : defaultSettings.name,
      email: typeof parsed.email === "string" ? parsed.email : defaultSettings.email,
      notifications: {
        ...defaultSettings.notifications,
        ...parsed.notifications || {}
      }
    };
  } catch {
    return defaultSettings;
  }
}
function Settings() {
  const [settings, setSettings] = reactExports.useState(loadSettings);
  reactExports.useEffect(() => {
    localStorage.setItem(settingsKey, JSON.stringify(settings));
  }, [settings]);
  const save = () => {
    localStorage.setItem(settingsKey, JSON.stringify(settings));
    pushNotification("success", "Настройки сохранены", "Параметры аккаунта и уведомлений обновлены.", "/settings");
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { title: "Настройки", description: "Параметры площадки и аккаунта" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-3xl space-y-6 p-8", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card p-6", style: {
        boxShadow: "var(--shadow-sm)"
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mb-1 font-semibold", children: "Профиль администратора" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-5 text-sm text-muted-foreground", children: "Базовая информация об аккаунте" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 sm:grid-cols-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "mb-1.5 block text-sm font-medium", children: "Имя" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: settings.name, onChange: (e) => setSettings((prev) => ({
              ...prev,
              name: e.target.value
            })), className: "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "mb-1.5 block text-sm font-medium", children: "Email" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { value: settings.email, onChange: (e) => setSettings((prev) => ({
              ...prev,
              email: e.target.value
            })), className: "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/20" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: save, className: "mt-5 rounded-lg px-4 py-2 text-sm font-semibold text-primary-foreground", style: {
          background: "var(--gradient-primary)"
        }, children: "Сохранить изменения" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card p-6", style: {
        boxShadow: "var(--shadow-sm)"
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mb-5 font-semibold", children: "Уведомления" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: notificationLabels.map((label) => /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center justify-between rounded-lg bg-muted/40 px-4 py-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-medium", children: label }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "checkbox", checked: settings.notifications[label] ?? false, onChange: (e) => setSettings((prev) => ({
            ...prev,
            notifications: {
              ...prev.notifications,
              [label]: e.target.checked
            }
          })), className: "h-4 w-4 accent-primary" })
        ] }, label)) })
      ] })
    ] })
  ] });
}
export {
  Settings as component
};
