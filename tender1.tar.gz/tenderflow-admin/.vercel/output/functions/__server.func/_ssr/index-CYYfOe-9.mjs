import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { d as useNavigate } from "../_libs/tanstack__react-router.mjs";
import { i as isAuthenticated } from "./auth-C1FwGTpK.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
function IndexRedirect() {
  const navigate = useNavigate();
  reactExports.useEffect(() => {
    if (isAuthenticated()) {
      navigate({
        to: "/dashboard",
        replace: true
      });
    } else {
      navigate({
        to: "/login",
        replace: true
      });
    }
  }, [navigate]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center", style: {
    background: "var(--gradient-hero)"
  }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center text-white", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto mb-4 h-10 w-10 animate-spin rounded-full border-2 border-white/30 border-t-white" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm opacity-80", children: "Загрузка..." })
  ] }) });
}
export {
  IndexRedirect as component
};
