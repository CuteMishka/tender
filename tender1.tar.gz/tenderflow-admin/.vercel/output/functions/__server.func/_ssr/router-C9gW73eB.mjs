import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { c as createRouter, u as useRouter, a as createRootRoute, b as createFileRoute, l as lazyRouteComponent, H as HeadContent, S as Scripts, O as Outlet, L as Link } from "../_libs/tanstack__react-router.mjs";
import { G as redirect } from "../_libs/tanstack__router-core.mjs";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "node:stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
const appCss = "/assets/styles-DO3qGYFE.css";
function NotFoundComponent() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-7xl font-bold text-foreground", children: "404" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-4 text-xl font-semibold text-foreground", children: "Page not found" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "The page you're looking for doesn't exist or has been moved." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      Link,
      {
        to: "/",
        className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
        children: "Go home"
      }
    ) })
  ] }) });
}
const Route$j = createRootRoute({
  ssr: false,
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Freedom Cloud — Админ-панель" },
      { name: "description", content: "Freedom Cloud — админ-панель" },
      { name: "author", content: "Freedom Cloud" },
      { property: "og:title", content: "Freedom Cloud — Админ-панель" },
      { property: "og:description", content: "Freedom Cloud — админ-панель" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "twitter:title", content: "Freedom Cloud — Админ-панель" },
      { name: "twitter:description", content: "Freedom Cloud — админ-панель" }
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss
      }
    ]
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent
});
function RootShell({ children }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("html", { lang: "en", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("head", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(HeadContent, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("body", { suppressHydrationWarning: true, children: [
      children,
      /* @__PURE__ */ jsxRuntimeExports.jsx(Scripts, {})
    ] })
  ] });
}
function RootComponent() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Outlet, {});
}
const $$splitComponentImporter$i = () => import("./login-vIvPaYMg.mjs");
const Route$i = createFileRoute("/login")({
  head: () => ({
    meta: [{
      title: "Вход — Freedom Cloud Админ"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$i, "component")
});
const $$splitComponentImporter$h = () => import("../_admin-BvTfH78I.mjs");
const Route$h = createFileRoute("/_admin")({
  component: lazyRouteComponent($$splitComponentImporter$h, "component")
});
const $$splitComponentImporter$g = () => import("./index-CYYfOe-9.mjs");
const Route$g = createFileRoute("/")({
  component: lazyRouteComponent($$splitComponentImporter$g, "component")
});
const $$splitComponentImporter$f = () => import("./users-DW76afPI.mjs");
const Route$f = createFileRoute("/_admin/users")({
  component: lazyRouteComponent($$splitComponentImporter$f, "component")
});
const $$splitComponentImporter$e = () => import("./tenders-CD7TTaQQ.mjs");
const Route$e = createFileRoute("/_admin/tenders")({
  component: lazyRouteComponent($$splitComponentImporter$e, "component")
});
const $$splitComponentImporter$d = () => import("./settings-xHld3ZI_.mjs");
const Route$d = createFileRoute("/_admin/settings")({
  component: lazyRouteComponent($$splitComponentImporter$d, "component")
});
const $$splitComponentImporter$c = () => import("./notifications-aX-pQ3pr.mjs");
const Route$c = createFileRoute("/_admin/notifications")({
  component: lazyRouteComponent($$splitComponentImporter$c, "component")
});
const $$splitComponentImporter$b = () => import("./dictionaries-B82eL7RV.mjs");
const Route$b = createFileRoute("/_admin/dictionaries")({
  component: lazyRouteComponent($$splitComponentImporter$b, "component")
});
const $$splitComponentImporter$a = () => import("./dashboard-Bjw_Tdxd.mjs");
const Route$a = createFileRoute("/_admin/dashboard")({
  component: lazyRouteComponent($$splitComponentImporter$a, "component")
});
const $$splitComponentImporter$9 = () => import("./companies-DH8KAizA.mjs");
const Route$9 = createFileRoute("/_admin/companies")({
  component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
const $$splitComponentImporter$8 = () => import("./bids-CV-oxkX-.mjs");
const Route$8 = createFileRoute("/_admin/bids")({
  component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
const $$splitComponentImporter$7 = () => import("./analytics-BFsOu0JM.mjs");
const Route$7 = createFileRoute("/_admin/analytics")({
  component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
const $$splitComponentImporter$6 = () => import("./tenders.index-CHGKwY_k.mjs");
const Route$6 = createFileRoute("/_admin/tenders/")({
  validateSearch: (raw) => {
    const page = Number(raw.page);
    return {
      page: Number.isFinite(page) && page >= 1 ? Math.floor(page) : 1
    };
  },
  ssr: false,
  component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
const $$splitComponentImporter$5 = () => import("./analytics.index-BTU5dmpx.mjs");
const Route$5 = createFileRoute("/_admin/analytics/")({
  beforeLoad: () => {
    throw redirect({
      to: "/analytics/historical"
    });
  },
  component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
const $$splitComponentImporter$4 = () => import("./tenders._tenderId-DsxyLslU.mjs");
const Route$4 = createFileRoute("/_admin/tenders/$tenderId")({
  ssr: false,
  component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
const $$splitComponentImporter$3 = () => import("./analytics.winners-P7qO_Gyj.mjs");
const Route$3 = createFileRoute("/_admin/analytics/winners")({
  component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
const $$splitComponentImporter$2 = () => import("./analytics.prices-oNluqfEv.mjs");
const Route$2 = createFileRoute("/_admin/analytics/prices")({
  component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
const $$splitComponentImporter$1 = () => import("./analytics.historical-B7SrepOD.mjs");
const Route$1 = createFileRoute("/_admin/analytics/historical")({
  component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
const $$splitComponentImporter = () => import("./analytics.customers-BoRm9cF5.mjs");
const Route = createFileRoute("/_admin/analytics/customers")({
  component: lazyRouteComponent($$splitComponentImporter, "component")
});
const LoginRoute = Route$i.update({
  id: "/login",
  path: "/login",
  getParentRoute: () => Route$j
});
const AdminRoute = Route$h.update({
  id: "/_admin",
  getParentRoute: () => Route$j
});
const IndexRoute = Route$g.update({
  id: "/",
  path: "/",
  getParentRoute: () => Route$j
});
const AdminUsersRoute = Route$f.update({
  id: "/users",
  path: "/users",
  getParentRoute: () => AdminRoute
});
const AdminTendersRoute = Route$e.update({
  id: "/tenders",
  path: "/tenders",
  getParentRoute: () => AdminRoute
});
const AdminSettingsRoute = Route$d.update({
  id: "/settings",
  path: "/settings",
  getParentRoute: () => AdminRoute
});
const AdminNotificationsRoute = Route$c.update({
  id: "/notifications",
  path: "/notifications",
  getParentRoute: () => AdminRoute
});
const AdminDictionariesRoute = Route$b.update({
  id: "/dictionaries",
  path: "/dictionaries",
  getParentRoute: () => AdminRoute
});
const AdminDashboardRoute = Route$a.update({
  id: "/dashboard",
  path: "/dashboard",
  getParentRoute: () => AdminRoute
});
const AdminCompaniesRoute = Route$9.update({
  id: "/companies",
  path: "/companies",
  getParentRoute: () => AdminRoute
});
const AdminBidsRoute = Route$8.update({
  id: "/bids",
  path: "/bids",
  getParentRoute: () => AdminRoute
});
const AdminAnalyticsRoute = Route$7.update({
  id: "/analytics",
  path: "/analytics",
  getParentRoute: () => AdminRoute
});
const AdminTendersIndexRoute = Route$6.update({
  id: "/",
  path: "/",
  getParentRoute: () => AdminTendersRoute
});
const AdminAnalyticsIndexRoute = Route$5.update({
  id: "/",
  path: "/",
  getParentRoute: () => AdminAnalyticsRoute
});
const AdminTendersTenderIdRoute = Route$4.update({
  id: "/$tenderId",
  path: "/$tenderId",
  getParentRoute: () => AdminTendersRoute
});
const AdminAnalyticsWinnersRoute = Route$3.update({
  id: "/winners",
  path: "/winners",
  getParentRoute: () => AdminAnalyticsRoute
});
const AdminAnalyticsPricesRoute = Route$2.update({
  id: "/prices",
  path: "/prices",
  getParentRoute: () => AdminAnalyticsRoute
});
const AdminAnalyticsHistoricalRoute = Route$1.update({
  id: "/historical",
  path: "/historical",
  getParentRoute: () => AdminAnalyticsRoute
});
const AdminAnalyticsCustomersRoute = Route.update({
  id: "/customers",
  path: "/customers",
  getParentRoute: () => AdminAnalyticsRoute
});
const AdminAnalyticsRouteChildren = {
  AdminAnalyticsCustomersRoute,
  AdminAnalyticsHistoricalRoute,
  AdminAnalyticsPricesRoute,
  AdminAnalyticsWinnersRoute,
  AdminAnalyticsIndexRoute
};
const AdminAnalyticsRouteWithChildren = AdminAnalyticsRoute._addFileChildren(
  AdminAnalyticsRouteChildren
);
const AdminTendersRouteChildren = {
  AdminTendersTenderIdRoute,
  AdminTendersIndexRoute
};
const AdminTendersRouteWithChildren = AdminTendersRoute._addFileChildren(
  AdminTendersRouteChildren
);
const AdminRouteChildren = {
  AdminAnalyticsRoute: AdminAnalyticsRouteWithChildren,
  AdminBidsRoute,
  AdminCompaniesRoute,
  AdminDashboardRoute,
  AdminDictionariesRoute,
  AdminNotificationsRoute,
  AdminSettingsRoute,
  AdminTendersRoute: AdminTendersRouteWithChildren,
  AdminUsersRoute
};
const AdminRouteWithChildren = AdminRoute._addFileChildren(AdminRouteChildren);
const rootRouteChildren = {
  IndexRoute,
  AdminRoute: AdminRouteWithChildren,
  LoginRoute
};
const routeTree = Route$j._addFileChildren(rootRouteChildren)._addFileTypes();
function DefaultErrorComponent({ error, reset }) {
  const router2 = useRouter();
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-destructive/10", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      "svg",
      {
        xmlns: "http://www.w3.org/2000/svg",
        className: "h-8 w-8 text-destructive",
        fill: "none",
        viewBox: "0 0 24 24",
        stroke: "currentColor",
        strokeWidth: 2,
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "path",
          {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            d: "M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z"
          }
        )
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-bold tracking-tight text-foreground", children: "Something went wrong" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "An unexpected error occurred. Please try again." }),
    false,
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 flex items-center justify-center gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => {
            router2.invalidate();
            reset();
          },
          className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
          children: "Try again"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "a",
        {
          href: "/",
          className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
          children: "Go home"
        }
      )
    ] })
  ] }) });
}
const getRouter = () => {
  const router2 = createRouter({
    routeTree,
    context: {},
    scrollRestoration: true,
    defaultPreloadStaleTime: 0,
    defaultErrorComponent: DefaultErrorComponent
  });
  return router2;
};
const router = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  getRouter
}, Symbol.toStringTag, { value: "Module" }));
export {
  Route$4 as R,
  router as r
};
