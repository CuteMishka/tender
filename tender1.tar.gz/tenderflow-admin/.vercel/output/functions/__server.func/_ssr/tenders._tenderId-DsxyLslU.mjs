import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { e as useLocation, d as useNavigate, L as Link } from "../_libs/tanstack__react-router.mjs";
import { P as PageHeader } from "./PageHeader-BgLmG3Y0.mjs";
import { a as analyticsApi, f as fmtM, b as fmtDate } from "./analytics-api-B0h335SN.mjs";
import { h as getFetchDocumentProxyUrl, i as fetchTenderById, m as markTenderViewed, j as getTenderViewInfo, k as getTenderSpecCache, l as indexLotDocument, n as fetchLotSpecSummary, o as saveTenderSpecCache, p as pickTenderDocumentForRag, q as fetchDocumentBlobViaBackendProxy, r as tenderDocumentBlobToFile, u as fetchLotAnalyze, d as getTenderStatus, t as tenderCompanyName, f as formatTenderAmount, e as formatDate, v as sanitizeApiTextMultiline, w as buildLotText, s as sanitizeApiText, g as getLocalApiBase, x as markTenderDecision } from "./tenders-api-s2Iw9WUl.mjs";
import { p as pushNotification } from "./use-notifications-sQ8SQxfy.mjs";
import { R as Route$4 } from "./router-C9gW73eB.mjs";
import { J as ArrowLeft, z as ThumbsUp, I as ThumbsDown, E as ExternalLink, K as Hash, F as FileText, t as DollarSign, v as MapPin, g as Building2, n as Clock, N as Calendar, O as Sparkles, H as History, Q as Upload, D as Download } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
function blockText(s) {
  return sanitizeApiText(s) || "—";
}
function specText(s) {
  if (!s) return "";
  return sanitizeApiTextMultiline(s);
}
function isRagUploadableFile(file) {
  const n = file.name.toLowerCase();
  return n.endsWith(".pdf") || n.endsWith(".docx") || n.endsWith(".doc");
}
function downloadTextFile(filename, text) {
  const blob = new Blob(["\uFEFF" + text], {
    type: "text/plain;charset=utf-8"
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
function downloadBlobFile(filename, blob) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
function InfoRow({
  label,
  value,
  icon: Icon
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3 py-2", children: [
    Icon && /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("dt", { className: "text-xs font-medium uppercase tracking-wider text-muted-foreground", children: label }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("dd", { className: "mt-0.5 text-sm text-foreground", children: value || "—" })
    ] })
  ] });
}
function scoreTone(score) {
  if (score >= 75) return {
    label: "Высокое соответствие",
    color: "bg-green-500",
    text: "text-green-700",
    border: "border-green-200",
    bg: "bg-green-50"
  };
  if (score >= 45) return {
    label: "Среднее соответствие",
    color: "bg-amber-500",
    text: "text-amber-700",
    border: "border-amber-200",
    bg: "bg-amber-50"
  };
  return {
    label: "Низкое соответствие",
    color: "bg-red-500",
    text: "text-red-700",
    border: "border-red-200",
    bg: "bg-red-50"
  };
}
function splitChecks(checks) {
  if (!checks) return [];
  return checks.split(/[;•\n]/).map((x) => x.trim()).filter(Boolean);
}
function truncateForAi(text, maxChars) {
  const t = specText(text);
  if (t.length <= maxChars) return t;
  return `${t.slice(0, maxChars)}

[Текст ТС обрезан до ${maxChars} символов для анализа]`;
}
function buildLotTextWithSpec(tender, spec, summary) {
  const parts = ["Проанализируй пригодность тендера для компании с учётом карточки лота и технической спецификации.", "", "Карточка лота:", buildLotText(tender)];
  if (summary && Object.keys(summary).length > 0) {
    parts.push("", "Структурированная выжимка ТС:", JSON.stringify(summary, null, 2));
  }
  if (specText(spec)) {
    parts.push("", "Извлечённый текст технической спецификации:", truncateForAi(spec, 12e3));
  }
  return parts.join("\n");
}
function tokenizeSimilarity(text) {
  const stop = /* @__PURE__ */ new Set(["для", "или", "при", "что", "как", "the", "and", "with", "услуг", "закупка", "поставка"]);
  const words = sanitizeApiText(text).toLowerCase().split(/[^a-zа-яё0-9]+/i).map((x) => x.trim()).filter((x) => x.length >= 4 && !stop.has(x));
  return new Set(words);
}
function similarScore(tender, lot) {
  const tenderTokens = tokenizeSimilarity(`${tender.title} ${tender.description} ${tender.purchaseType ?? ""} ${tenderCompanyName(tender)}`);
  const lotTokens = tokenizeSimilarity(`${lot.title} ${lot.description} ${lot.purchase_type} ${lot.customer_name} ${lot.organizer_name}`);
  let score = 0;
  for (const token of tenderTokens) {
    if (lotTokens.has(token)) score += 3;
  }
  if (tender.purchaseType && lot.purchase_type && tender.purchaseType.toLowerCase() === lot.purchase_type.toLowerCase()) score += 8;
  const company = tenderCompanyName(tender).toLowerCase();
  if (company && `${lot.customer_name} ${lot.organizer_name}`.toLowerCase().includes(company)) score += 10;
  if (Number.isFinite(tender.cost) && tender.cost > 0 && lot.initial_amount > 0) {
    const ratio = Math.min(tender.cost, lot.initial_amount) / Math.max(tender.cost, lot.initial_amount);
    score += ratio * 5;
  }
  return score;
}
function LotAnalysisCard({
  analysis
}) {
  const score = Math.max(0, Math.min(100, Math.round(analysis.score)));
  const tone = scoreTone(score);
  const checks = splitChecks(analysis.checks);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `space-y-4 rounded-xl border ${tone.border} ${tone.bg} p-4`, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: "Вердикт AI" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-1 flex flex-wrap items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `rounded-full bg-background px-3 py-1 text-sm font-semibold ${tone.text}`, children: analysis.fit }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-sm font-medium ${tone.text}`, children: tone.label })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-left sm:text-right", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `text-3xl font-bold ${tone.text}`, children: [
          score,
          "%"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground", children: "пригодность лота" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-1.5 flex justify-between text-[11px] text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "0%" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "50%" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "100%" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-3 overflow-hidden rounded-full bg-background/80", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `h-full rounded-full ${tone.color} transition-all`, style: {
        width: `${score}%`
      } }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 lg:grid-cols-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-lg border border-border/60 bg-background/80 p-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: "Краткий вывод" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm leading-relaxed text-foreground", children: analysis.summary })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-lg border border-border/60 bg-background/80 p-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: "Обоснование" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm leading-relaxed text-foreground", children: analysis.reason })
      ] })
    ] }),
    checks.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-lg border border-border/60 bg-background/80 p-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: "Что проверить" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "space-y-1.5 text-sm text-foreground", children: checks.map((check, index) => /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: check })
      ] }, `${check}-${index}`)) })
    ] })
  ] });
}
function TenderDetail() {
  const {
    tenderId
  } = Route$4.useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const id = Number(tenderId);
  const [tender, setTender] = reactExports.useState(null);
  const [error, setError] = reactExports.useState(null);
  const [loading, setLoading] = reactExports.useState(true);
  const [lotAnalysis, setLotAnalysis] = reactExports.useState(null);
  const [lotAnalysisLoading, setLotAnalysisLoading] = reactExports.useState(false);
  const [lotAnalysisError, setLotAnalysisError] = reactExports.useState(null);
  const [ragFile, setRagFile] = reactExports.useState(null);
  const [ragExtractSpecPoints, setRagExtractSpecPoints] = reactExports.useState(false);
  const [ragIncludeExtractedText, setRagIncludeExtractedText] = reactExports.useState(true);
  const [ragPanelOpen, setRagPanelOpen] = reactExports.useState(false);
  const [ragUploadLoading, setRagUploadLoading] = reactExports.useState(false);
  const [ragUploadError, setRagUploadError] = reactExports.useState(null);
  const [ragUploadOk, setRagUploadOk] = reactExports.useState(null);
  const [ragExtractedOverride, setRagExtractedOverride] = reactExports.useState(null);
  const [ragSpecSummary, setRagSpecSummary] = reactExports.useState(null);
  const [specDownloadLoading, setSpecDownloadLoading] = reactExports.useState(false);
  const [actionLoading, setActionLoading] = reactExports.useState(null);
  const [viewInfo, setViewInfo] = reactExports.useState(null);
  const [similarLots, setSimilarLots] = reactExports.useState([]);
  const [similarLotsLoading, setSimilarLotsLoading] = reactExports.useState(false);
  const [similarLotsError, setSimilarLotsError] = reactExports.useState(null);
  const ragAutoViaProxyKeyRef = reactExports.useRef(null);
  const fetchDocumentProxyUrl = getFetchDocumentProxyUrl();
  const returnPage = typeof location.state === "object" && location.state !== null && "tendersPage" in location.state && typeof location.state.tendersPage === "number" ? Math.max(1, Math.floor(location.state.tendersPage)) : 1;
  reactExports.useEffect(() => {
    if (!Number.isFinite(id) || id < 1) {
      setLoading(false);
      setError("Некорректный ID");
      return;
    }
    let cancelled = false;
    setLoading(true);
    setError(null);
    fetchTenderById(id).then((t) => {
      if (!cancelled) {
        setTender(t);
        markTenderViewed(id);
        setViewInfo(getTenderViewInfo(id));
      }
    }).catch((e) => {
      if (!cancelled) setError(e instanceof Error ? e.message : String(e));
    }).finally(() => {
      if (!cancelled) setLoading(false);
    });
    return () => {
      cancelled = true;
    };
  }, [id]);
  reactExports.useEffect(() => {
    ragAutoViaProxyKeyRef.current = null;
    setRagFile(null);
    setRagExtractSpecPoints(false);
    setRagIncludeExtractedText(true);
    setRagUploadError(null);
    setRagUploadOk(null);
    setSpecDownloadLoading(false);
    const cached = Number.isFinite(id) && id > 0 ? getTenderSpecCache(id) : null;
    setRagExtractedOverride(typeof cached?.extractedText === "string" ? cached.extractedText : null);
    setRagSpecSummary(cached?.specSummary && typeof cached.specSummary === "object" ? cached.specSummary : null);
  }, [id]);
  const submitSpecToRag = reactExports.useCallback(async (file, opts) => {
    if (!tender) throw new Error("Нет данных тендера");
    setRagUploadLoading(true);
    setRagUploadError(null);
    setRagUploadOk(null);
    try {
      const result = await indexLotDocument(String(tender.id), file, {
        sourceHint: opts.sourceHintSuffix ? `tender-${tender.id};${opts.sourceHintSuffix}` : `tender-${tender.id}`,
        extractSpecPoints: opts.extractSpecPoints,
        includeExtractedText: opts.includeExtractedText
      });
      const nextExtracted = result.extracted_text !== void 0 && opts.includeExtractedText ? result.extracted_text : ragExtractedOverride ?? void 0;
      if (result.extracted_text !== void 0 && opts.includeExtractedText) {
        setRagExtractedOverride(result.extracted_text);
      }
      let nextSummary;
      if (result.spec_summary && Object.keys(result.spec_summary).length > 0) {
        setRagSpecSummary(result.spec_summary);
        nextSummary = result.spec_summary;
      } else if (opts.extractSpecPoints) {
        const saved = await fetchLotSpecSummary(String(tender.id)).catch(() => null);
        if (saved && Object.keys(saved).length > 0) {
          setRagSpecSummary(saved);
          nextSummary = saved;
        }
      }
      const parts = [];
      if (result.indexed) parts.push("документ проиндексирован");
      if (typeof result.text_chars === "number") parts.push(`${result.text_chars} символов текста`);
      const status = parts.length ? parts.join(" · ") : "Готово.";
      setRagUploadOk(status);
      saveTenderSpecCache(tender.id, {
        extractedText: nextExtracted,
        specSummary: nextSummary ?? ragSpecSummary ?? void 0,
        uploadStatus: status
      });
    } finally {
      setRagUploadLoading(false);
    }
  }, [ragExtractedOverride, ragSpecSummary, tender]);
  reactExports.useEffect(() => {
    if (!fetchDocumentProxyUrl || !tender) return;
    const picked = pickTenderDocumentForRag(tender.documents);
    if (!picked) return;
    const key = `${tender.id}${picked.downloadLink}`;
    if (ragAutoViaProxyKeyRef.current === key) return;
    ragAutoViaProxyKeyRef.current = key;
    let cancelled = false;
    (async () => {
      try {
        const blob = await fetchDocumentBlobViaBackendProxy(picked.downloadLink);
        if (cancelled) return;
        const file = tenderDocumentBlobToFile(picked, blob);
        await submitSpecToRag(file, {
          extractSpecPoints: false,
          includeExtractedText: true,
          sourceHintSuffix: `proxy;${picked.name}`
        });
      } catch (e) {
        ragAutoViaProxyKeyRef.current = null;
        if (!cancelled) setRagUploadError(e instanceof Error ? e.message : String(e));
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [tender, fetchDocumentProxyUrl, submitSpecToRag]);
  const displayTechnicalSpec = specText(ragExtractedOverride ?? void 0) || specText(tender?.technical_specification);
  reactExports.useEffect(() => {
    if (!tender) return;
    let cancelled = false;
    setSimilarLotsLoading(true);
    setSimilarLotsError(null);
    analyticsApi.getLots({
      status: "completed",
      excluded: "include",
      page: 1,
      limit: 100
    }).then((res) => {
      if (cancelled) return;
      const ranked = (res.items ?? []).filter((lot) => lot.lot_id !== tender.id).map((lot) => ({
        lot,
        score: similarScore(tender, lot)
      })).filter((x) => x.score > 0).sort((a, b) => b.score - a.score).slice(0, 5).map((x) => x.lot);
      setSimilarLots(ranked);
    }).catch((e) => {
      if (!cancelled) setSimilarLotsError(e instanceof Error ? e.message : String(e));
    }).finally(() => {
      if (!cancelled) setSimilarLotsLoading(false);
    });
    return () => {
      cancelled = true;
    };
  }, [tender]);
  const handleLotAnalyze = reactExports.useCallback(async () => {
    if (!tender || lotAnalysisLoading) return;
    const lotText = buildLotTextWithSpec(tender, displayTechnicalSpec, ragSpecSummary);
    setLotAnalysisLoading(true);
    setLotAnalysisError(null);
    try {
      const result = await fetchLotAnalyze(lotText, {
        cacheKey: `tender-${tender.id}-${displayTechnicalSpec ? "with-spec" : "card-only"}`
      });
      setLotAnalysis(result);
    } catch (e) {
      setLotAnalysisError(e instanceof Error ? e.message : String(e));
    } finally {
      setLotAnalysisLoading(false);
    }
  }, [displayTechnicalSpec, ragSpecSummary, tender, lotAnalysisLoading]);
  async function handleRagUpload(e) {
    e.preventDefault();
    if (!tender || !ragFile) return;
    if (!isRagUploadableFile(ragFile)) {
      setRagUploadError("Допустимы только файлы .pdf, .docx или .doc.");
      return;
    }
    try {
      await submitSpecToRag(ragFile, {
        extractSpecPoints: ragExtractSpecPoints,
        includeExtractedText: ragIncludeExtractedText
      });
    } catch (err) {
      setRagUploadError(err instanceof Error ? err.message : String(err));
    }
  }
  async function handleDownloadOriginalSpec() {
    if (!tender || specDownloadLoading) return;
    const picked = pickTenderDocumentForRag(tender.documents);
    if (!picked) {
      setRagUploadError("В документах тендера не найдена ТС в формате PDF/DOC/DOCX.");
      return;
    }
    setSpecDownloadLoading(true);
    setRagUploadError(null);
    try {
      const blob = await fetchDocumentBlobViaBackendProxy(picked.downloadLink);
      downloadBlobFile(picked.name || `tender-${tender.id}-technical-specification`, blob);
      setRagUploadOk(`ТС скачана: ${picked.name || "файл"}`);
    } catch (err) {
      setRagUploadError(err instanceof Error ? err.message : String(err));
    } finally {
      setSpecDownloadLoading(false);
    }
  }
  const handleDecision = async (status) => {
    if (!tender) return;
    setActionLoading(status);
    try {
      const deadline = tender.endDate ? new Date(tender.endDate).toISOString() : new Date(Date.now() + 30 * 24 * 60 * 60 * 1e3).toISOString();
      const payload = {
        id: tender.id,
        title: tender.title || "Без названия",
        description: tender.description || "",
        amount: tender.cost || 0,
        status,
        deadline,
        start_date: tender.startDate ? new Date(tender.startDate).toISOString() : (/* @__PURE__ */ new Date()).toISOString(),
        end_date: deadline,
        purchase_type: tender.purchaseType || "—",
        organizer_name: tenderCompanyName(tender),
        partner_link: tender.partnerLink || ""
      };
      const res = await fetch(`${getLocalApiBase()}/api/v1/lots/participate`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new Error("Ошибка при сохранении");
      const title = blockText(tender.title).slice(0, 60);
      markTenderDecision(tender.id, status);
      if (status === "participating") {
        pushNotification("success", "Участвуем", `Тендер «${title}» добавлен в заявки.`, "/bids");
        navigate({
          to: "/bids"
        });
      } else {
        pushNotification("info", "Не подходит", `Тендер «${title}» отклонён.`);
        navigate({
          to: "/tenders",
          search: {
            page: returnPage
          }
        });
      }
    } catch (err) {
      pushNotification("error", "Ошибка", "Не удалось обновить статус тендера.");
    } finally {
      setActionLoading(null);
    }
  };
  const pickedSpecDocument = tender ? pickTenderDocumentForRag(tender.documents) : null;
  const statusInfo = tender ? getTenderStatus(tender.endDate) : null;
  const companyName = tender ? tenderCompanyName(tender) : "";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageHeader, { title: loading ? "Тендер" : tender ? blockText(tender.title).slice(0, 80) : "Тендер", description: tender ? `ID ${tender.id} · закупка buy_id ${tender.buy_id}` : void 0, actions: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/tenders", search: {
      page: returnPage
    }, className: "inline-flex items-center gap-2 rounded-lg border border-border bg-background px-4 py-2 text-sm font-medium hover:bg-accent", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "h-4 w-4" }),
      " К списку"
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-8", children: [
      error && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-xl border border-destructive/30 bg-destructive/10 px-6 py-4 text-sm text-destructive", children: error }),
      loading && !tender && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-center rounded-xl border border-border bg-card px-6 py-24 text-sm text-muted-foreground", children: "Загрузка…" }),
      tender && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card p-6", style: {
          boxShadow: "var(--shadow-sm)"
        }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: "Решение об участии" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Подходит ли лот профилю компании? Выберите действие." })
            ] }),
            viewInfo && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-right text-xs text-muted-foreground shrink-0 ml-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                "Просмотрел: ",
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-foreground", children: viewInfo.viewer })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: new Date(viewInfo.viewedAt).toLocaleString("ru-RU") }),
              viewInfo.decision && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `mt-1 inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-medium ${viewInfo.decision === "participating" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-600"}`, children: viewInfo.decision === "participating" ? "Участвуем" : "Отклонён" })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => handleDecision("participating"), disabled: actionLoading !== null, className: "inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground shadow-sm transition hover:opacity-90 disabled:opacity-50", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ThumbsUp, { className: "h-4 w-4" }),
              actionLoading === "participating" ? "Сохранение…" : "Подходит"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => handleDecision("rejected"), disabled: actionLoading !== null, className: "inline-flex items-center gap-2 rounded-xl border border-destructive/40 bg-destructive/10 px-5 py-2.5 text-sm font-semibold text-destructive transition hover:bg-destructive/20 disabled:opacity-50", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ThumbsDown, { className: "h-4 w-4" }),
              actionLoading === "rejected" ? "Сохранение…" : "Не подходит"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href: tender.partnerLink, target: "_blank", rel: "noopener noreferrer", className: "inline-flex items-center gap-2 rounded-xl border border-border bg-background px-5 py-2.5 text-sm font-medium text-primary hover:bg-accent", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "h-4 w-4" }),
              " Открыть на площадке"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 lg:grid-cols-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-2 rounded-xl border border-border bg-card", style: {
            boxShadow: "var(--shadow-sm)"
          }, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "border-b border-border px-6 py-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold uppercase tracking-wider text-muted-foreground", children: "Описание" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("dl", { className: "divide-y divide-border px-6", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(InfoRow, { label: "Лот", value: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono text-xs", children: tender.lot }), icon: Hash }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(InfoRow, { label: "Наименование", value: blockText(tender.title), icon: FileText }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(InfoRow, { label: "Сумма", value: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-semibold text-base", children: [
                formatTenderAmount(tender.cost),
                " ₸"
              ] }), icon: DollarSign }),
              tender.region && /* @__PURE__ */ jsxRuntimeExports.jsx(InfoRow, { label: "Регион", value: tender.region, icon: MapPin }),
              tender.partner && /* @__PURE__ */ jsxRuntimeExports.jsx(InfoRow, { label: "Площадка", value: tender.partner, icon: Building2 }),
              companyName && /* @__PURE__ */ jsxRuntimeExports.jsx(InfoRow, { label: "Заказчик / компания", value: companyName, icon: Building2 }),
              tender.status && /* @__PURE__ */ jsxRuntimeExports.jsx(InfoRow, { label: "Статус", value: tender.status, icon: Hash }),
              tender.place && /* @__PURE__ */ jsxRuntimeExports.jsx(InfoRow, { label: "Место", value: blockText(tender.place), icon: MapPin }),
              tender.description && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("dt", { className: "text-xs font-medium uppercase tracking-wider text-muted-foreground", children: "Описание" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("dd", { className: "mt-1.5 text-sm leading-relaxed text-muted-foreground", children: blockText(tender.description) })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card", style: {
              boxShadow: "var(--shadow-sm)"
            }, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "border-b border-border px-6 py-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold uppercase tracking-wider text-muted-foreground", children: "Детали тендера" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("dl", { className: "divide-y divide-border px-6", children: [
                tender.endDate && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("dt", { className: "flex items-center gap-1.5 text-xs font-medium uppercase tracking-wider text-muted-foreground", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "h-3.5 w-3.5" }),
                    " Завершение приёма заявок"
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("dd", { className: `mt-1 text-sm font-semibold ${statusInfo?.color === "red" ? "text-red-600" : "text-foreground"}`, children: [
                    formatDate(tender.endDate),
                    statusInfo && statusInfo.daysLeft !== null && statusInfo.daysLeft >= 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `ml-2 rounded-full px-2 py-0.5 text-xs font-medium ${statusInfo.color === "red" ? "bg-red-100 text-red-600" : statusInfo.color === "orange" ? "bg-orange-100 text-orange-600" : "bg-green-100 text-green-700"}`, children: statusInfo.daysLeft === 0 ? "сегодня" : `${statusInfo.daysLeft} дн.` })
                  ] })
                ] }),
                tender.startDate && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("dt", { className: "flex items-center gap-1.5 text-xs font-medium uppercase tracking-wider text-muted-foreground", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "h-3.5 w-3.5" }),
                    " Начало подачи"
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("dd", { className: "mt-1 text-sm text-foreground", children: formatDate(tender.startDate) })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("dt", { className: "text-xs font-medium uppercase tracking-wider text-muted-foreground", children: "Место" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("dd", { className: "mt-1 text-sm text-foreground", children: blockText(tender.place) })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("dt", { className: "text-xs font-medium uppercase tracking-wider text-muted-foreground", children: "Источник лота" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("dd", { className: "mt-1 font-mono text-xs text-foreground", children: tender.lot_source_id ?? "—" })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card", style: {
              boxShadow: "var(--shadow-sm)"
            }, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "border-b border-border px-6 py-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold uppercase tracking-wider text-muted-foreground", children: "Документы" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-4 py-3", children: tender.documents && tender.documents.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "space-y-1", children: tender.documents.map((doc, i) => /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href: doc.downloadLink, target: "_blank", rel: "noopener noreferrer", className: "flex items-center gap-2 rounded-lg px-3 py-2 text-sm transition hover:bg-muted/60", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(FileText, { className: "h-4 w-4 shrink-0 text-muted-foreground" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "min-w-0 flex-1 truncate font-medium text-primary hover:underline", children: blockText(doc.name) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "h-3.5 w-3.5 shrink-0 text-muted-foreground" })
              ] }) }, `${doc.downloadLink}-${i}`)) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "py-2 text-sm text-muted-foreground", children: "Файлов нет." }) })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card", style: {
          boxShadow: "var(--shadow-sm)"
        }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "border-b border-border px-6 py-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "flex items-center gap-2 text-sm font-semibold uppercase tracking-wider text-muted-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "h-4 w-4 text-primary" }),
            " AI Анализ"
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-6 py-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: handleLotAnalyze, disabled: lotAnalysisLoading || Boolean(lotAnalysis), className: "inline-flex items-center gap-2 rounded-lg border border-border bg-background px-4 py-2 text-sm font-medium hover:bg-accent disabled:opacity-50", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "h-4 w-4" }),
                lotAnalysisLoading ? "Анализирую…" : lotAnalysis ? "Анализ выполнен" : "Запустить AI-анализ"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-xs text-muted-foreground", children: "Запрос к AI выполняется только вручную. Повторный одинаковый результат может вернуться из локального кэша без расхода лимита." })
            ] }),
            lotAnalysisLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-sm text-muted-foreground", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-4 w-4 animate-spin rounded-full border-2 border-muted border-t-primary" }),
              "Анализирую…"
            ] }) : lotAnalysis ? /* @__PURE__ */ jsxRuntimeExports.jsx(LotAnalysisCard, { analysis: lotAnalysis }) : lotAnalysisError ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-destructive", children: lotAnalysisError }),
              specText(tender.ai_analysis) && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-h-[min(24rem,50vh)] overflow-y-auto rounded-lg border border-border bg-muted/30 px-4 py-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx("pre", { className: "whitespace-pre-wrap break-words font-sans text-sm leading-relaxed text-foreground", children: specText(tender.ai_analysis) }) })
            ] }) : specText(tender.ai_analysis) ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-h-[min(32rem,70vh)] overflow-y-auto rounded-lg border border-primary/20 bg-primary/5 px-4 py-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx("pre", { className: "whitespace-pre-wrap break-words font-sans text-sm leading-relaxed text-foreground", children: specText(tender.ai_analysis) }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Ответ анализа пуст или RAG-сервис недоступен." })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card", style: {
          boxShadow: "var(--shadow-sm)"
        }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border-b border-border px-6 py-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "flex items-center gap-2 text-sm font-semibold uppercase tracking-wider text-muted-foreground", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(History, { className: "h-4 w-4 text-primary" }),
              " Похожие выполненные заказы"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-muted-foreground", children: "Сравнение с историей завершённых лотов по названию, описанию, заказчику, виду закупки и сумме." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-6 py-4", children: similarLotsLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-sm text-muted-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-4 w-4 animate-spin rounded-full border-2 border-muted border-t-primary" }),
            "Ищу похожие заказы…"
          ] }) : similarLotsError ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-destructive", children: similarLotsError }) : similarLots.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-3 lg:grid-cols-2", children: similarLots.map((lot) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-lg border border-border bg-muted/20 p-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-2 flex flex-wrap items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rounded-full bg-green-100 px-2 py-0.5 text-[10px] font-semibold uppercase text-green-700", children: "выполнен" }),
              lot.purchase_type && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rounded-full bg-background px-2 py-0.5 text-[10px] text-muted-foreground", children: lot.purchase_type })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "line-clamp-2 text-sm font-semibold text-foreground", children: blockText(lot.title) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-muted-foreground", children: lot.customer_name || lot.organizer_name || "Заказчик не указан" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 grid gap-2 text-xs text-muted-foreground sm:grid-cols-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block uppercase tracking-wider", children: "Бюджет" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-medium text-foreground", children: [
                  fmtM(lot.initial_amount),
                  " ₸"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block uppercase tracking-wider", children: "Дата" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-foreground", children: fmtDate(lot.end_date) })
              ] }),
              lot.winner_name && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "sm:col-span-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block uppercase tracking-wider", children: "Победитель" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-foreground", children: lot.winner_name })
              ] })
            ] }),
            lot.partner_link && /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href: lot.partner_link, target: "_blank", rel: "noopener noreferrer", className: "mt-3 inline-flex items-center gap-1 text-xs font-medium text-primary hover:underline", children: [
              "Открыть прошлый лот ",
              /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "h-3 w-3" })
            ] })
          ] }, lot.id)) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Похожих выполненных заказов пока не найдено. Они появятся после заполнения истории в аналитике." }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-border bg-card", style: {
          boxShadow: "var(--shadow-sm)"
        }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border-b border-border px-6 py-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold uppercase tracking-wider text-muted-foreground", children: "Техническая спецификация" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-muted-foreground", children: "Загрузите ТЗ для индексации в RAG (PDF, DOCX) или скачайте техническую спецификацию из документов тендера." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-6 py-4 space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: () => setRagPanelOpen((v) => !v), className: "inline-flex items-center gap-2 rounded-lg border border-border bg-background px-4 py-2 text-sm font-medium hover:bg-accent", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "h-4 w-4" }),
                ragPanelOpen ? "Скрыть загрузку" : "Загрузить ТЗ в RAG"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: handleDownloadOriginalSpec, disabled: !pickedSpecDocument || specDownloadLoading, className: "inline-flex items-center gap-2 rounded-lg border border-border bg-background px-4 py-2 text-sm font-medium hover:bg-accent disabled:opacity-50", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "h-4 w-4" }),
                specDownloadLoading ? "Скачивание…" : "Скачать ТС"
              ] }),
              displayTechnicalSpec && /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: () => downloadTextFile(`tender-${tender.id}-technical-specification.txt`, displayTechnicalSpec), className: "inline-flex items-center gap-2 rounded-lg border border-border bg-background px-4 py-2 text-sm font-medium hover:bg-accent", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "h-4 w-4" }),
                " Скачать текст"
              ] })
            ] }),
            pickedSpecDocument && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-muted-foreground", children: [
              "Найден файл ТС: ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-foreground", children: blockText(pickedSpecDocument.name) })
            ] }),
            ragPanelOpen && /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleRagUpload, className: "space-y-3 rounded-lg border border-border bg-muted/20 p-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-end gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-w-[200px] flex-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx("input", { id: "rag-spec-file", type: "file", accept: ".pdf,.doc,.docx", className: "block w-full text-sm text-foreground file:mr-3 file:rounded-md file:border file:border-border file:bg-background file:px-3 file:py-1.5 file:text-sm file:font-medium", disabled: ragUploadLoading, onChange: (ev) => {
                  const f = ev.target.files?.[0];
                  setRagFile(f ?? null);
                  setRagUploadError(null);
                  setRagUploadOk(null);
                } }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "submit", disabled: ragUploadLoading || !ragFile, className: "inline-flex items-center gap-2 rounded-lg border border-border bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-50", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "h-4 w-4" }),
                  ragUploadLoading ? "Отправка…" : "Отправить в RAG"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-4 text-sm", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex cursor-pointer items-center gap-2 text-muted-foreground", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "checkbox", className: "rounded", checked: ragExtractSpecPoints, disabled: ragUploadLoading, onChange: (e) => setRagExtractSpecPoints(e.target.checked) }),
                  "Выжимка через OpenAI"
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex cursor-pointer items-center gap-2 text-muted-foreground", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "checkbox", className: "rounded", checked: ragIncludeExtractedText, disabled: ragUploadLoading, onChange: (e) => setRagIncludeExtractedText(e.target.checked) }),
                  "Включить текст в ответе"
                ] })
              ] }),
              ragUploadError && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-destructive", children: ragUploadError }),
              ragUploadOk && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: ragUploadOk })
            ] }),
            ragSpecSummary && Object.keys(ragSpecSummary).length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2", children: "Выжимка ТЗ (RAG)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-h-80 overflow-y-auto rounded-lg border border-border bg-muted/20 px-4 py-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx("pre", { className: "whitespace-pre-wrap break-words font-mono text-xs leading-relaxed text-foreground", children: JSON.stringify(ragSpecSummary, null, 2) }) })
            ] }),
            displayTechnicalSpec ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2", children: "Извлечённый текст" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-h-[min(32rem,70vh)] overflow-y-auto rounded-lg border border-border bg-muted/20 px-4 py-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx("pre", { className: "whitespace-pre-wrap break-words font-sans text-sm leading-relaxed text-foreground", children: displayTechnicalSpec }) })
            ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Нет текста — загрузите файл выше." })
          ] })
        ] })
      ] })
    ] })
  ] });
}
export {
  TenderDetail as component
};
