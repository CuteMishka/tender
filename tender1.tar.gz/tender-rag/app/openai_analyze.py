"""Анализ профиля и найденных фрагментов через Gemini."""

from __future__ import annotations

import json
from typing import Any

from app.config import gemini_chat_json

MAX_CONTEXT_CHARS = 24_000

SYSTEM_PROMPT = """Ты помощник по госзакупкам и ИТ-услугам (Казахстан).
На входе:
1) Профиль компании — что умеют и чем занимаются.
2) Опционально сырые данные с API о лоте.
3) Фрагменты из базы (чанки ТЗ), уже отобранные по семантической близости; у каждого лота есть lot_id и score.

Правила:
- Сопоставь профиль с содержанием фрагментов по каждому lot_id. Не придумывай факты — только то, что следует из текста.
- Не гарантируй победу или допуск к участию.

Ответ строго JSON (без markdown, без пояснений вне JSON) формата:
{
  "summary": "1–2 предложения: общий вывод по списку",
  "verdicts": [
    {
      "lot_id": "строка — точно как во входных данных",
      "fit": "подходит" или "сомнительно" или "не подходит",
      "reason": "1–2 коротких предложения"
    }
  ]
}

Для КАЖДОГО lot_id из списка совпадений должен быть ровно один объект в verdicts."""

SYSTEM_LOT_ONLY = """Ты помощник по госзакупкам и ИТ (Казахстан).
Даны: профиль компании и текст лота (описание, ТЗ, JSON — как есть).
Оцени, насколько лот соответствует возможностям компании ТОЛЬКО по этим текстам.
Не выдумывай факты. Не гарантируй победу или допуск.

Ответ строго JSON:
{
  "summary": "1–2 предложения общий вывод",
  "fit": "подходит" или "сомнительно" или "не подходит",
  "score": число от 0 до 100 — процент соответствия лота профилю компании,
  "reason": "2–4 предложения: почему так",
  "checks": "что специалисту проверить в полных документах (список через точку с запятой)"
}

Шкала score:
- 0–30: лот почти не соответствует профилю;
- 31–60: есть косвенное или частичное соответствие;
- 61–85: лот в целом подходит, но есть условия для проверки;
- 86–100: лот хорошо соответствует профилю."""


def _truncate(s: str, limit: int) -> str:
    s = s.strip()
    if len(s) <= limit:
        return s
    return s[: limit - 20] + "\n… [обрезано]"


def build_user_prompt(
    profile: str,
    matches: list[dict[str, Any]],
    incoming: str | None,
) -> str:
    parts: list[str] = []
    parts.append("### Профиль компании\n" + profile.strip())
    if incoming and incoming.strip():
        parts.append(
            "### Данные с API / про лот (опционально)\n"
            + _truncate(incoming.strip(), 8000)
        )
    lines = ["### Совпадения из базы (lot_id, score, фрагменты)", ""]
    for m in matches:
        lid = m.get("lot_id", "")
        sc = m.get("score", 0)
        lines.append(f"lot_id: {lid}")
        lines.append(f"score: {sc:.4f}")
        for sn in m.get("snippets") or []:
            lines.append(_truncate(sn, 3500))
            lines.append("")
        lines.append("---")
    blob = "\n".join(lines)
    combined = "\n\n".join(parts) + "\n\n" + blob
    return _truncate(combined, MAX_CONTEXT_CHARS)


def analyze_match_context(
    profile: str,
    matches: list[dict[str, Any]],
    incoming: str | None = None,
) -> dict[str, Any]:
    """Возвращает dict с ключами summary и verdicts."""
    user_prompt = build_user_prompt(profile, matches, incoming)
    lot_ids = [str(m.get("lot_id", "")) for m in matches]
    user_prompt += (
        "\n\n### Список lot_id для verdicts (все должны попасть в JSON):\n"
        + json.dumps(lot_ids, ensure_ascii=False)
    )

    data = gemini_chat_json(SYSTEM_PROMPT, user_prompt, temperature=0.2)

    summary = (data.get("summary") or "").strip()
    verdicts_raw = data.get("verdicts")
    if not isinstance(verdicts_raw, list):
        raise RuntimeError("В ответе нет массива verdicts")

    verdicts: list[dict[str, str]] = []
    for v in verdicts_raw:
        if not isinstance(v, dict):
            continue
        verdicts.append({
            "lot_id": str(v.get("lot_id", "")).strip(),
            "fit": str(v.get("fit", "сомнительно")).strip(),
            "reason": str(v.get("reason", "")).strip(),
        })

    if not summary:
        summary = "Краткий вывод недоступен — проверьте фрагменты вручную."

    return {"summary": summary, "verdicts": verdicts}


def _score_from_fit(fit: str) -> int:
    normalized = fit.strip().lower()
    if "не" in normalized and "подходит" in normalized:
        return 20
    if "подходит" in normalized:
        return 85
    return 50


def _normalize_score(value: Any, fit: str) -> int:
    try:
        score = int(round(float(value)))
    except (TypeError, ValueError):
        score = _score_from_fit(fit)
    return max(0, min(100, score))


def analyze_lot_without_index(company_profile: str, lot_text: str) -> dict[str, Any]:
    """Разбор одного лота без векторного индекса."""
    lot_text = _truncate(lot_text.strip(), 18_000)
    if not lot_text:
        raise ValueError("lot_text пуст")

    user = (
        "### Профиль компании\n"
        + company_profile.strip()
        + "\n\n### Текст лота\n"
        + lot_text
    )

    data = gemini_chat_json(SYSTEM_LOT_ONLY, user, temperature=0.2)
    fit = str(data.get("fit", "сомнительно")).strip() or "сомнительно"
    return {
        "summary": str(data.get("summary", "")).strip() or "—",
        "fit": fit,
        "score": _normalize_score(data.get("score"), fit),
        "reason": str(data.get("reason", "")).strip() or "—",
        "checks": str(data.get("checks", "")).strip() or None,
    }
